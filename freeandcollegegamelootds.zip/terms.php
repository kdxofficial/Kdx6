<?
include_once('inc/bd.php');
include_once('inc/config.php');

$sid = $_COOKIE['sid'];
$query = ("SELECT * FROM `users` WHERE `sid` = '$sid'");
$result = mysqli_query($link,$query);
$user = mysqli_fetch_array($result);

if($user){
    $money = $user['money'];
    $id = $user['id'];
    $prava = $user['prava'];
}

$query = ("SELECT * FROM `users` WHERE `sid` = '$sid'");
$result = mysqli_query($link,$query);
$search = mysqli_num_rows($result);

$search = mysqli_num_rows($result);
if($search == 0){
  header('Location: /');
}


/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/

?>
<html style="--vh:3.18px;">
<head>
  <title>Пользовательское соглашение <? echo $site_name;?></title>
  <meta data-n-head="ssr" charset="utf-8">
  <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta data-n-head="ssr" name="apple-mobile-web-app-title" content="<? echo $site_name;?>">
  <meta data-n-head="ssr" name="application-name" content="<? echo $site_name;?>">
  <meta data-n-head="ssr" name="msapplication-TileColor" content="#ffffff">
  <meta data-n-head="ssr" name="msapplication-config" content="/favicon/browserconfig.xml">
  <meta data-n-head="ssr" name="theme-color" content="#ffffff">
  <link data-n-head="ssr" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,600&amp;display=swap&amp;subset=cyrillic-ext">
  <link data-n-head="ssr" rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-touch-icon.png">
  <link data-n-head="ssr" rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
  <link data-n-head="ssr" rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
  <link data-n-head="ssr" rel="manifest" href="/favicon/site.webmanifest">
  <link data-n-head="ssr" rel="mask-icon" href="/favicon/safari-pinned-tab.svg" color="381960">
  <link data-n-head="ssr" rel="shortcut icon" href="/favicon/favicon.ico">
  <link rel="preload" href="/_nuxt/6ba65d7d2a278b53c9ad.js" as="script">
  <link rel="preload" href="/_nuxt/ea4d0e1418afcfa94ce5.js" as="script">
  <link rel="preload" href="/_nuxt/5bac75f34425993c48d3.js" as="script">
  <link rel="preload" href="/_nuxt/d134dc5d8c6407c75152.js" as="script">
  <link rel="preload" href="/_nuxt/d7687b6839a98c59cdd8.js" as="script">
  <style data-vue-ssr-id="4f857918:0 2901aeae:0 3191d5ad:0 932a8f60:0 3c054965:0 7294dc5e:0 3db2ea20:0 7cd1bdc3:0 9f002ef8:0 b035a29a:0 52d2ce5c:0 0e0eb82f:0 22efe3a0:0 34bf7ba4:0 47e7e198:0 b9d01396:0 1765e5ca:0 44df22ea:0 66402b96:0 9ae97294:0 36d6a109:0 0ebf4dcb:0 f9cc371a:0 293cc79e:0 60edd0f6:0 ede60a42:0 b6c3e0b8:0 f1add17c:0 62c7f3c4:0 515e6b90:0 5f9a150f:0 5a214042:0 ba8e1006:0 e1a087e2:0 0311afca:0 28a3f015:0 0075ccc4:0 1bda4f16:0 1056a1e2:0">
    /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
    
    html {
      line-height: 1.15;
      -webkit-text-size-adjust: 100%
    }
    
    body {
      margin: 0
    }
    
    main {
      display: block
    }
    
    h1 {
      font-size: 2em;
      margin: .67em 0
    }
    
    hr {
      box-sizing: content-box;
      height: 0;
      overflow: visible
    }
    
    pre {
      font-family: monospace, monospace;
      font-size: 1em
    }
    
    a {
      background-color: transparent
    }
    
    abbr[title] {
      border-bottom: none;
      text-decoration: underline;
      -webkit-text-decoration: underline dotted;
      text-decoration: underline dotted
    }
    
    b,
    strong {
      font-weight: bolder
    }
    
    code,
    kbd,
    samp {
      font-family: monospace, monospace;
      font-size: 1em
    }
    
    small {
      font-size: 80%
    }
    
    sub,
    sup {
      font-size: 75%;
      line-height: 0;
      position: relative;
      vertical-align: baseline
    }
    
    sub {
      bottom: -.25em
    }
    
    sup {
      top: -.5em
    }
    
    img {
      border-style: none
    }
    
    button,
    input,
    optgroup,
    select,
    textarea {
      font-family: inherit;
      font-size: 100%;
      line-height: 1.15;
      margin: 0
    }
    
    button,
    input {
      overflow: visible
    }
    
    button,
    select {
      text-transform: none
    }
    
    [type=button],
    [type=reset],
    [type=submit],
    button {
      -webkit-appearance: button
    }
    
    [type=button]::-moz-focus-inner,
    [type=reset]::-moz-focus-inner,
    [type=submit]::-moz-focus-inner,
    button::-moz-focus-inner {
      border-style: none;
      padding: 0
    }
    
    [type=button]:-moz-focusring,
    [type=reset]:-moz-focusring,
    [type=submit]:-moz-focusring,
    button:-moz-focusring {
      outline: 1px dotted ButtonText
    }
    
    fieldset {
      padding: .35em .75em .625em
    }
    
    legend {
      box-sizing: border-box;
      color: inherit;
      display: table;
      max-width: 100%;
      padding: 0;
      white-space: normal
    }
    
    progress {
      vertical-align: baseline
    }
    
    textarea {
      overflow: auto
    }
    
    [type=checkbox],
    [type=radio] {
      box-sizing: border-box;
      padding: 0
    }
    
    [type=number]::-webkit-inner-spin-button,
    [type=number]::-webkit-outer-spin-button {
      height: auto
    }
    
    [type=search] {
      -webkit-appearance: textfield;
      outline-offset: -2px
    }
    
    [type=search]::-webkit-search-decoration {
      -webkit-appearance: none
    }
    
    ::-webkit-file-upload-button {
      -webkit-appearance: button;
      font: inherit
    }
    
    details {
      display: block
    }
    
    summary {
      display: list-item
    }
    
    [hidden],
    template {
      display: none
    }
    
    .vue-notification-group {
      display: block;
      position: fixed;
      z-index: 5000
    }
    
    .vue-notification-wrapper {
      display: block;
      overflow: hidden;
      width: 100%;
      margin: 0;
      padding: 0
    }
    
    .notification-title {
      font-weight: 600
    }
    
    .vue-notification-template {
      background: #fff
    }
    
    .vue-notification,
    .vue-notification-template {
      display: block;
      box-sizing: border-box;
      text-align: left
    }
    
    .vue-notification {
      font-size: 12px;
      padding: 10px;
      margin: 0 5px 5px;
      color: #fff;
      background: #44a4fc;
      border-left: 5px solid #187fe7
    }
    
    .vue-notification.warn {
      background: #ffb648;
      border-left-color: #f48a06
    }
    
    .vue-notification.error {
      background: #e54d42;
      border-left-color: #b82e24
    }
    
    .vue-notification.success {
      background: #68cd86;
      border-left-color: #42a85f
    }
    
    .vn-fade-enter-active,
    .vn-fade-leave-active,
    .vn-fade-move {
      transition: all .5s
    }
    
    .vn-fade-enter,
    .vn-fade-leave-to {
      opacity: 0
    }
    
    .nuxt-progress {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 2px;
      width: 0;
      opacity: 1;
      -webkit-transition: width .1s, opacity .4s;
      transition: width .1s, opacity .4s;
      background-color: #fff;
      z-index: 999999
    }
    
    .nuxt-progress.nuxt-progress-notransition {
      -webkit-transition: none;
      transition: none
    }
    
    .nuxt-progress-failed {
      background-color: red
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      -ms-overflow-style: none;
      scrollbar-width: none
    }
    
    body {
      background: #381960;
      font-family: Source Sans Pro, sans-serif;
      font-size: 14px
    }
    
    ul {
      margin: 0;
      padding: 0
    }
    
    a {
      color: #ffed2a;
      text-decoration: none
    }
    
    h1,
    h2,
    h3,
    h4,
    h5 {
      color: #fff;
      font-weight: 700
    }
    
    h2 {
      font-size: 30px
    }
    
    h3 {
      font-size: 26px
    }
    
    h4 {
      font-size: 20px
    }
    
    circle,
    path,
    rect {
      -webkit-transition: all .3s;
      transition: all .3s
    }
    
    a,
    button,
    input,
    select,
    textarea {
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0)
    }
    
    .vue-notification-group {
      display: block;
      position: fixed;
      z-index: 5000
    }
    
    .vue-notification-wrapper {
      display: block;
      overflow: hidden;
      width: 100%;
      margin: 0;
      padding: 0
    }
    
    .notification-title {
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      line-height: 18px
    }
    
    .vue-notification,
    .vue-notification-template {
      display: block;
      box-sizing: border-box;
      background: #fff;
      text-align: left
    }
    
    .vue-notification {
      font-size: 14px;
      line-height: 20px;
      padding: 10px 15px;
      margin: 5px;
      color: #3f2652;
      border-radius: 4px;
      box-shadow: 0 5px 10px 0 rgba(0, 0, 0, .6)
    }
    
    .vue-notification.warn {
      background: #ffb648
    }
    
    .vue-notification.error {
      background: #ff5553;
      color: #fff
    }
    
    .vue-notification.success {
      background: #4dc500;
      color: #fff
    }
    
    .vn-fade-enter-active,
    .vn-fade-leave-active,
    .vn-fade-move {
      -webkit-transition: all .5s;
      transition: all .5s
    }
    
    .vn-fade-enter,
    .vn-fade-leave-to {
      opacity: 0
    }
    
    .content[data-v-31cda96b] {
      border-bottom: 1px solid hsla(0, 0%, 100%, .2);
      padding-bottom: 17px
    }
    
    @media screen and (max-width:719px) {
      .content[data-v-31cda96b] {
        border-bottom: none;
        padding-bottom: 0
      }
    }
    
    .content__wrap[data-v-31cda96b] {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 30px;
      display: -webkit-box;
      display: flex
    }
    
    @media screen and (max-width:719px) {
      .content__wrap[data-v-31cda96b] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        padding: 0
      }
    }
    
    .content__header[data-v-31cda96b] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-transform: translateX(-3px);
      transform: translateX(-3px);
      margin-bottom: 5px
    }
    
    @media screen and (max-width:850px) {
      .content__header[data-v-31cda96b] {
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column
      }
    }
    
    @media screen and (max-width:719px) {
      .content__header[data-v-31cda96b] {
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        flex-direction: row;
        -webkit-transform: none;
        transform: none;
        padding: 0 0 0 9px
      }
    }
    
    @media screen and (max-width:719px) {
      .content__header span[data-v-31cda96b] {
        display: none
      }
    }
    
    .content__header h1[data-v-31cda96b] {
      font-size: 48px;
      font-weight: 800;
      color: #fff;
      margin: 0
    }
    
    @media screen and (max-width:719px) {
      .content__header h1[data-v-31cda96b] {
        font-size: 26px
      }
    }
    
    .header[data-v-180c07fb] {
      height: 82px;
      -webkit-box-pack: justify;
      justify-content: space-between;
      padding: 0 30px;
      max-width: 1200px;
      margin: 0 auto
    }
    
    .header[data-v-180c07fb],
    .header__user[data-v-180c07fb] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    @media (max-width:1199px) {
      .header[data-v-180c07fb] {
        height: 60px;
        padding: 0 10px
      }
    }
    
    .logo[data-v-2b804d1f] {
      display: block;
      width: 110px;
      height: 29px;
font-size: 25px;    }
    
    @media (max-width:1199px) {
      .logo[data-v-2b804d1f] {
        width: 33px;
        height: 30px;
      }
    }
    
    .menu-desktop[data-v-52012dc4] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: start;
      justify-content: flex-start;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .menu__item[data-v-52012dc4] {
      list-style: none;
      margin-right: 50px
    }
    
    .menu__item[data-v-52012dc4]:last-child {
      margin-right: 0
    }
    
    .menu__link[data-v-52012dc4] {
      display: inline-block;
      font-size: 16px;
      color: #a698af;
      -webkit-transition: color .2s ease-in-out;
      transition: color .2s ease-in-out;
      cursor: pointer
    }
    
    .menu__link[data-v-52012dc4]:hover {
      color: #fff
    }
    
    .menu__link_active[data-v-52012dc4] {
      position: relative;
      color: #fff
    }
    
    .menu__link_active[data-v-52012dc4]:after {
      content: "";
      width: 100%;
      height: 2px;
      background-color: #ffed2a;
      position: absolute;
      bottom: -5px;
      left: 0
    }
    
    @media (max-width:1199px) {
      .menu-desktop[data-v-52012dc4] {
        display: none
      }
    }
    
    @media screen and (min-width:1200px) {
      .menu-mobile[data-v-58233ac6] {
        display: none!important
      }
    }
    
    .menu-mobile[data-v-58233ac6] {
      height: 50px;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: justify;
      justify-content: space-between;
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 10;
      padding: 0 10px;
      background: #381960;
      border-top: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    .menu-mobile[data-v-58233ac6],
    .menu__items[data-v-58233ac6] {
      display: -webkit-box;
      display: flex
    }
    
    .menu__items[data-v-58233ac6] {
      -webkit-box-align: start;
      align-items: flex-start;
      -webkit-box-pack: start;
      justify-content: flex-start;
      height: 100%
    }
    
    .menu__item[data-v-58233ac6] {
      display: block;
      list-style: none;
      font-size: 10px;
      color: #a698af;
      padding-top: 10px;
      margin-right: 20px;
      text-align: center
    }
    
    .menu__link[data-v-58233ac6] {
      display: inline-block;
      color: #a698af;
      -webkit-transition: color .2s ease-in-out;
      transition: color .2s ease-in-out;
      cursor: pointer
    }
    
    .menu__link_active[data-v-58233ac6] {
      color: #fff
    }
    
    .menu__icon_default[data-v-58233ac6] {
      display: inline
    }
    
    .menu__icon_active[data-v-58233ac6],
    .menu__link_active .menu__icon_default[data-v-58233ac6] {
      display: none
    }
    
    .menu__link_active .menu__icon_active[data-v-58233ac6] {
      display: inline
    }
    
    .menu__additional[data-v-58233ac6] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: start;
      justify-content: flex-start;
      border-radius: 5px;
      background-color: hsla(0, 0%, 100%, .1);
      padding: 8px 9px 8px 11px
    }
    
    .chat-button[data-v-75f76985] {
      width: 18px;
      height: 18px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDE4IDE4Ij4KICAgIDxwYXRoIGZpbGw9IiNCMEFBQjMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTguNSAxNC43NTljNS4yNDcgMCA5LjUtMS43MTQgOS41LTcuMzhTMTQuNzQ3IDAgOS41IDAgMCAxLjcxMyAwIDcuMzhjMCAzLjUzMyAxLjY1NSA1LjUzIDQuMTczIDYuNTMxLjE2Ni45NzctLjU1OCAyLjM0LTIuMTczIDQuMDg5IDMuNTIyLS41MDggNS41MjItMS41MDggNi0zIC43MDEtLjAwMy0uMDgzLS4yNDEuNS0uMjQxem0tMS4yMy0uNzU2bC0uMjIyLjY5MmMtLjIyLjY4OS0xLjA3MSAxLjI5OS0yLjU5IDEuNzYzLjU5OC0xLjAwMi44NC0xLjg5Ny43LTIuNzE1bC0uMDk0LS41NTMtLjUyMS0uMjA4QzIuMjA0IDEyLjA1MiAxIDEwLjI5IDEgNy4zOCAxIDIuOTIzIDMuOTA5IDEgOS41IDEgMTQuNzYyIDEgMTcgMi43MzIgMTcgNy4zOGMwIDQuNDU1LTIuOTA5IDYuMzc5LTguNSA2LjM3OS0uMzYyIDAtLjU4NS4wMzItLjgzNy4yNDJsLS4zOTQuMDAyeiIvPgo8L3N2Zz4K) no-repeat 50%
    }
    
    .balance[data-v-1d7aa3c2] {
      font-size: 26px;
      font-weight: 700;
      color: #ffed2a
    }
    
    @media (max-width:1199px) {
      .balance[data-v-1d7aa3c2] {
        font-size: 20px
      }
    }
    
    .wallet[data-v-2f84b7f5] {
      display: block;
      width: 86px;
      height: 34px;
      font-size: 12px;
      font-weight: 700;
      line-height: 1.5;
      text-transform: uppercase;
      margin-left: 15px;
      color: #fff;
      background: url(/_nuxt/img/06f9df4.svg) no-repeat 50%;
      -webkit-transition: background-image .2s ease-in-out;
      transition: background-image .2s ease-in-out;
      text-decoration: none;
      padding-left: 11px;
      padding-top: 8px
    }
    
    .wallet[data-v-2f84b7f5]:hover {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4NiIgaGVpZ2h0PSIzNCIgdmlld0JveD0iMCAwIDg2IDM0Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTc5LjU5IDBjMi4yMyAwIDMuMDM3LjIzMiAzLjg1Mi42NjhhNC41NDMgNC41NDMgMCAwIDEgMS44OSAxLjg5Yy40MzYuODE1LjY2OCAxLjYyMy42NjggMy44NTJ2MjEuMThjMCAyLjIzLS4yMzIgMy4wMzctLjY2OCAzLjg1MmE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5IDEuODljLS44MTUuNDM2LTEuNjIzLjY2OC0zLjg1Mi42NjhINi40MWMtMi4yMyAwLTMuMDM3LS4yMzItMy44NTItLjY2OGE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5LTEuODlDLjIzMiAzMC42MjcgMCAyOS44MiAwIDI3LjU5VjYuNDFjMC0yLjIzLjIzMi0zLjAzNy42NjgtMy44NTJhNC41NDMgNC41NDMgMCAwIDEgMS44OS0xLjg5QzMuMzczLjIzMiA0LjE4IDAgNi40MSAwaDczLjE4em0uMjY0IDJINi40MWMtMS43MyAwLTIuMzEyLjExMi0yLjkwOS40MzEtLjQ2Ni4yNS0uODIuNjA0LTEuMDcgMS4wNy0uMzAyLjU2NS0uNDE5IDEuMTE3LS40MyAyLjY0NUwyIDI3LjU5YzAgMS43My4xMTIgMi4zMTIuNDMxIDIuOTA5LjI1LjQ2Ni42MDQuODIgMS4wNyAxLjA3LjU5Ny4zMTkgMS4xNzkuNDMxIDIuOTA5LjQzMWg3My4xOGMxLjczIDAgMi4zMTItLjExMiAyLjkwOS0uNDMxLjQ2Ni0uMjUuODItLjYwNCAxLjA3LTEuMDcuMzE5LS41OTcuNDMxLTEuMTc5LjQzMS0yLjkwOVYyMmgtNmEzIDMgMCAwIDEtMy0zdi00YTMgMyAwIDAgMSAzLTNoNlY2LjQxYzAtMS43My0uMTEyLTIuMzEyLS40MzEtMi45MDlhMi41NDQgMi41NDQgMCAwIDAtMS4wNy0xLjA3Yy0uNTY1LS4zMDItMS4xMTctLjQxOS0yLjY0NS0uNDN6TTg0IDEzaC02YTIgMiAwIDAgMC0yIDJ2NGEyIDIgMCAwIDAgMiAyaDZ2LTh6bS00IDJhMiAyIDAgMSAxIDAgNCAyIDIgMCAwIDEgMC00eiIvPgo8L3N2Zz4K)
    }
    
    .wallet[data-v-2f84b7f5]:active {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4NiIgaGVpZ2h0PSIzNCIgdmlld0JveD0iMCAwIDg2IDM0Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkVEMkEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTc5LjU5IDBjMi4yMyAwIDMuMDM3LjIzMiAzLjg1Mi42NjhhNC41NDMgNC41NDMgMCAwIDEgMS44OSAxLjg5Yy40MzYuODE1LjY2OCAxLjYyMy42NjggMy44NTJ2MjEuMThjMCAyLjIzLS4yMzIgMy4wMzctLjY2OCAzLjg1MmE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5IDEuODljLS44MTUuNDM2LTEuNjIzLjY2OC0zLjg1Mi42NjhINi40MWMtMi4yMyAwLTMuMDM3LS4yMzItMy44NTItLjY2OGE0LjU0MyA0LjU0MyAwIDAgMS0xLjg5LTEuODlDLjIzMiAzMC42MjcgMCAyOS44MiAwIDI3LjU5VjYuNDFjMC0yLjIzLjIzMi0zLjAzNy42NjgtMy44NTJhNC41NDMgNC41NDMgMCAwIDEgMS44OS0xLjg5QzMuMzczLjIzMiA0LjE4IDAgNi40MSAwaDczLjE4em0uMjY0IDJINi40MWMtMS43MyAwLTIuMzEyLjExMi0yLjkwOS40MzEtLjQ2Ni4yNS0uODIuNjA0LTEuMDcgMS4wNy0uMzAyLjU2NS0uNDE5IDEuMTE3LS40MyAyLjY0NUwyIDI3LjU5YzAgMS43My4xMTIgMi4zMTIuNDMxIDIuOTA5LjI1LjQ2Ni42MDQuODIgMS4wNyAxLjA3LjU5Ny4zMTkgMS4xNzkuNDMxIDIuOTA5LjQzMWg3My4xOGMxLjczIDAgMi4zMTItLjExMiAyLjkwOS0uNDMxLjQ2Ni0uMjUuODItLjYwNCAxLjA3LTEuMDcuMzE5LS41OTcuNDMxLTEuMTc5LjQzMS0yLjkwOVYyMmgtNmEzIDMgMCAwIDEtMy0zdi00YTMgMyAwIDAgMSAzLTNoNlY2LjQxYzAtMS43My0uMTEyLTIuMzEyLS40MzEtMi45MDlhMi41NDQgMi41NDQgMCAwIDAtMS4wNy0xLjA3Yy0uNTY1LS4zMDItMS4xMTctLjQxOS0yLjY0NS0uNDN6TTg0IDEzaC02YTIgMiAwIDAgMC0yIDJ2NGEyIDIgMCAwIDAgMiAyaDZ2LTh6bS00IDJhMiAyIDAgMSAxIDAgNCAyIDIgMCAwIDEgMC00eiIvPgo8L3N2Zz4K)
    }
    
    @media (max-width:1199px) {
      .wallet[data-v-2f84b7f5] {
        margin-left: 11px
      }
    }
    
    .profile[data-v-2be93831] {
      width: 26px;
      height: 26px;
      margin-left: 15px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIyNiIgdmlld0JveD0iMCAwIDI2IDI2Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtb3BhY2l0eT0iLjIiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEzIDBjNy4xOCAwIDEzIDUuODIgMTMgMTNzLTUuODIgMTMtMTMgMTNTMCAyMC4xOCAwIDEzIDUuODIgMCAxMyAwem0wIDJDNi45MjUgMiAyIDYuOTI1IDIgMTNjMCAzLjM1OSAxLjUwNiA2LjM2NiAzLjg3OSA4LjM4NEw1LjUgMjAuNWw0LjUxMi0xLjI5MlYxNi43NWMtLjA2NC0uMDU4LS4xMjctLjExLS4xODUtLjE2Ny0xLjA3OS0xLjA0NS0xLjYzOS0yLjUxNi0xLjYzOS00LjAxNnYtMi40OEE0LjIxMyA0LjIxMyAwIDAgMSAxMi40IDUuODc1aDEuMTJhNC4yMTMgNC4yMTMgMCAwIDEgNC4yMSA0LjIxMnYyLjQ4YzAgMS41LS41NTkgMi45NzEtMS42MzggNC4wMTZsLS4xODQuMTY3djIuNDU4TDIwLjUgMjAuNWwuMTQuNDE1QzIyLjcxIDE4LjkxNSAyNCAxNi4xMDggMjQgMTNjMC02LjA3NS00LjkyNS0xMS0xMS0xMXoiLz4KPC9zdmc+Cg==) no-repeat 50%;
      -webkit-transition: background-image .2s ease-in-out;
      transition: background-image .2s ease-in-out;
      cursor: pointer;
      text-decoration: none
    }
    
    .profile[data-v-2be93831]:hover {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIyNiIgdmlld0JveD0iMCAwIDI2IDI2Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEzIDBjNy4xOCAwIDEzIDUuODIgMTMgMTNzLTUuODIgMTMtMTMgMTNTMCAyMC4xOCAwIDEzIDUuODIgMCAxMyAwem0wIDJDNi45MjUgMiAyIDYuOTI1IDIgMTNjMCAzLjM1OSAxLjUwNiA2LjM2NiAzLjg3OSA4LjM4NEw1LjUgMjAuNWw0LjUxMi0xLjI5MlYxNi43NWMtLjA2NC0uMDU4LS4xMjctLjExLS4xODUtLjE2Ny0xLjA3OS0xLjA0NS0xLjYzOS0yLjUxNi0xLjYzOS00LjAxNnYtMi40OEE0LjIxMyA0LjIxMyAwIDAgMSAxMi40IDUuODc1aDEuMTJhNC4yMTMgNC4yMTMgMCAwIDEgNC4yMSA0LjIxMnYyLjQ4YzAgMS41LS41NTkgMi45NzEtMS42MzggNC4wMTZsLS4xODQuMTY3djIuNDU4TDIwLjUgMjAuNWwuMTQuNDE1QzIyLjcxIDE4LjkxNSAyNCAxNi4xMDggMjQgMTNjMC02LjA3NS00LjkyNS0xMS0xMS0xMXoiLz4KPC9zdmc+Cg==)
    }
    
    .profile[data-v-2be93831]:active {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIyNiIgdmlld0JveD0iMCAwIDI2IDI2Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkVEMkEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEzIDBjNy4xOCAwIDEzIDUuODIgMTMgMTNzLTUuODIgMTMtMTMgMTNTMCAyMC4xOCAwIDEzIDUuODIgMCAxMyAwem0wIDJDNi45MjUgMiAyIDYuOTI1IDIgMTNjMCAzLjM1OSAxLjUwNiA2LjM2NiAzLjg3OSA4LjM4NEw1LjUgMjAuNWw0LjUxMi0xLjI5MlYxNi43NWMtLjA2NC0uMDU4LS4xMjctLjExLS4xODUtLjE2Ny0xLjA3OS0xLjA0NS0xLjYzOS0yLjUxNi0xLjYzOS00LjAxNnYtMi40OEE0LjIxMyA0LjIxMyAwIDAgMSAxMi40IDUuODc1aDEuMTJhNC4yMTMgNC4yMTMgMCAwIDEgNC4yMSA0LjIxMnYyLjQ4YzAgMS41LS41NTkgMi45NzEtMS42MzggNC4wMTZsLS4xODQuMTY3djIuNDU4TDIwLjUgMjAuNWwuMTQuNDE1QzIyLjcxIDE4LjkxNSAyNCAxNi4xMDggMjQgMTNjMC02LjA3NS00LjkyNS0xMS0xMS0xMXoiLz4KPC9zdmc+Cg==)
    }
    
    @media (max-width:1199px) {
      .profile[data-v-2be93831] {
        margin-left: 11px
      }
    }
    
    .main-page[data-v-84c2ab78] {
      width: 100%
    }
    
    .main-page__menu[data-v-84c2ab78] {
      width: 100%;
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      max-width: 1200px;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .main-page__benefits[data-v-84c2ab78] {
      margin-top: 25px
    }
    
    .main-page__columnns[data-v-84c2ab78] {
      display: -webkit-box;
      display: flex;
      margin-top: 5px;
      padding-bottom: 10px
    }
    
    .main-page__chat[data-v-84c2ab78] {
      margin-top: 20px;
      padding-left: 20px
    }
    
    @media screen and (max-width:1100px) {
      .main-page[data-v-84c2ab78] {
        padding: 0
      }
      .main-page__menu[data-v-84c2ab78] {
        max-width: auto;
        padding: 0 10px
      }
      .main-page__benefits[data-v-84c2ab78] {
        margin-top: 10px
      }
      .main-page__columnns[data-v-84c2ab78] {
        display: block
      }
      .main-page__chat[data-v-84c2ab78] {
        display: none
      }
    }
    
    .game-cover {
      cursor: pointer;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      height: 302px
    }
    
    .game-cover_disabled {
      cursor: default
    }
    
    .game-cover__wrapper {
      position: relative;
      height: 100%;
      -webkit-transition: -webkit-transform .3s;
      transition: -webkit-transform .3s;
      transition: transform .3s;
      transition: transform .3s, -webkit-transform .3s
    }
    
    .game-cover:not(.game-cover_disabled):hover .game-cover__wrapper {
      -webkit-transform: translateY(-5px);
      transform: translateY(-5px)
    }
    
    .game-cover:not(.game-cover_disabled):hover .game-cover__image {
      box-shadow: 0 8px 20px 0 rgba(0, 0, 0, .3)
    }
    
    .game-cover__image {
      border-radius: 7px;
      -webkit-transition: box-shadow .3s, -webkit-transform .3s;
      transition: box-shadow .3s, -webkit-transform .3s;
      transition: transform .3s, box-shadow .3s;
      transition: transform .3s, box-shadow .3s, -webkit-transform .3s
    }
    
    .game-cover__name {
      position: absolute;
      left: 23px;
      bottom: 23px;
      z-index: 1;
      color: #fff;
      font-size: 26px;
      font-weight: 700
    }
    
    .game-cover__later,
    .game-cover__novelty {
      position: absolute;
      top: 20px;
      right: 0;
      width: 75px;
      height: 31px;
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .game-cover__later,
      .game-cover__novelty {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAYFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6T+iNAAAAIHRSTlPLAMeiv1XEuZYnHwunn5qSFxIFtH11a2FRTUM7M4mISpspbwcAAADySURBVGje1dqHEcIwEETR/eScc+y/S8DgwTYNfF4FmrF0uj05AIdBPzKwbMeH1SBCdGPEPEb0YoTuEBaYxoh7jMBYtgKjTnyASys6AMfo8LKLDYVrZCiMbceRt+U6KnwMXWWC0llVJii5Gi++tvHgayXqCKkYT2JB1ULTE1IztLTQ1J3iQMM+CjQ50ixNI0W1p8kRhfixicDfLMv5EaVb3lkgnOXUefk4r2pnY+NsA6VNszNiOAOZM746w75zNCIdJN0iIx5SOke6zgG49LnAcz9XcIgRsxhh3FkJwmP45HxO1P5w4NzzsDCuC6DbtsTD0gMZMQZgpm54ewAAAABJRU5ErkJggg==)
      }
    }
    
    .game-cover__later,
    .game-cover__novelty {
      background: -webkit-image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAYFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6T+iNAAAAIHRSTlPLAMeiv1XEuZYnHwunn5qSFxIFtH11a2FRTUM7M4mISpspbwcAAADySURBVGje1dqHEcIwEETR/eScc+y/S8DgwTYNfF4FmrF0uj05AIdBPzKwbMeH1SBCdGPEPEb0YoTuEBaYxoh7jMBYtgKjTnyASys6AMfo8LKLDYVrZCiMbceRt+U6KnwMXWWC0llVJii5Gi++tvHgayXqCKkYT2JB1ULTE1IztLTQ1J3iQMM+CjQ50ixNI0W1p8kRhfixicDfLMv5EaVb3lkgnOXUefk4r2pnY+NsA6VNszNiOAOZM746w75zNCIdJN0iIx5SOke6zgG49LnAcz9XcIgRsxhh3FkJwmP45HxO1P5w4NzzsDCuC6DbtsTD0gMZMQZgpm54ewAAAABJRU5ErkJggg==) 2x);
      background: image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAYFBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6T+iNAAAAIHRSTlPLAMeiv1XEuZYnHwunn5qSFxIFtH11a2FRTUM7M4mISpspbwcAAADySURBVGje1dqHEcIwEETR/eScc+y/S8DgwTYNfF4FmrF0uj05AIdBPzKwbMeH1SBCdGPEPEb0YoTuEBaYxoh7jMBYtgKjTnyASys6AMfo8LKLDYVrZCiMbceRt+U6KnwMXWWC0llVJii5Gi++tvHgayXqCKkYT2JB1ULTE1IztLTQ1J3iQMM+CjQ50ixNI0W1p8kRhfixicDfLMv5EaVb3lkgnOXUefk4r2pnY+NsA6VNszNiOAOZM746w75zNCIdJN0iIx5SOke6zgG49LnAcz9XcIgRsxhh3FkJwmP45HxO1P5w4NzzsDCuC6DbtsTD0gMZMQZgpm54ewAAAABJRU5ErkJggg==) 2x);
      color: #fff;
      font-size: 13px;
      font-weight: 700;
      padding-top: 8px;
      padding-left: 21px
    }
    
    .game-cover__later {
      background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .game-cover__later {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAyQL40Pzzuyfu6OPCtWxpYR0Wq5yShnlUST81LQ0JXB3XCDIAAAD7SURBVGje1dmHlcJAEATRYs/AGbz3nX+UeBBSABQ/Ar2n3ZnpWYAyaP/GBRi1ogOlHR/oRwi6EYLvCMFfhEB4DxPYRwj4jA/Q+YkOwOojNpwMYsPZLDJcjOPCxU5WvbgauYo9NxtVb+Ru+RUPHnrxoGIaDSqKZyKkaqvp2jwZWoIZz9aSrk3NIgrUzWNAgyLN0tAxVHvqHFGIpkle730+y/kTpUfeWSCc5dTZfJyt2jnYOMdA6dDsjBjOQOaMr86w71yNSBdJzrWbc0npXOk6F+DO54Ki6c/v8Pr6HyEQnqwEfNfwyPmcGNeYdQfFeOaBofC7OOm3VDPg0QEvUEibQZcMnwAAAABJRU5ErkJggg==)
      }
    }
    
    .game-cover__later {
      background: -webkit-image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAyQL40Pzzuyfu6OPCtWxpYR0Wq5yShnlUST81LQ0JXB3XCDIAAAD7SURBVGje1dmHlcJAEATRYs/AGbz3nX+UeBBSABQ/Ar2n3ZnpWYAyaP/GBRi1ogOlHR/oRwi6EYLvCMFfhEB4DxPYRwj4jA/Q+YkOwOojNpwMYsPZLDJcjOPCxU5WvbgauYo9NxtVb+Ru+RUPHnrxoGIaDSqKZyKkaqvp2jwZWoIZz9aSrk3NIgrUzWNAgyLN0tAxVHvqHFGIpkle730+y/kTpUfeWSCc5dTZfJyt2jnYOMdA6dDsjBjOQOaMr86w71yNSBdJzrWbc0npXOk6F+DO54Ki6c/v8Pr6HyEQnqwEfNfwyPmcGNeYdQfFeOaBofC7OOm3VDPg0QEvUEibQZcMnwAAAABJRU5ErkJggg==) 2x);
      background: image-set(url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC) 1x, url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA+CAMAAAD+kBJTAAAAY1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////+aRQ2gAAAAIHRSTlMAyQL40Pzzuyfu6OPCtWxpYR0Wq5yShnlUST81LQ0JXB3XCDIAAAD7SURBVGje1dmHlcJAEATRYs/AGbz3nX+UeBBSABQ/Ar2n3ZnpWYAyaP/GBRi1ogOlHR/oRwi6EYLvCMFfhEB4DxPYRwj4jA/Q+YkOwOojNpwMYsPZLDJcjOPCxU5WvbgauYo9NxtVb+Ru+RUPHnrxoGIaDSqKZyKkaqvp2jwZWoIZz9aSrk3NIgrUzWNAgyLN0tAxVHvqHFGIpkle730+y/kTpUfeWSCc5dTZfJyt2jnYOMdA6dDsjBjOQOaMr86w71yNSBdJzrWbc0npXOk6F+DO54Ki6c/v8Pr6HyEQnqwEfNfwyPmcGNeYdQfFeOaBofC7OOm3VDPg0QEvUEibQZcMnwAAAABJRU5ErkJggg==) 2x);
      color: #3f2652
    }
    
    .game-cover__toner {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 0;
      width: 100%;
      height: 100%;
      border-radius: 7px;
      background: rgba(0, 0, 0, .4)
    }
    
    @-moz-document url-prefix() {
      .game-cover__novelty {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAOVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC8dlA9AAAAE3RSTlPLAMHIVTAVBr2brqJ/cGFNQx4Pq2jKPwAAAGVJREFUSMfl1csNwDAIA1AcSv5p0+w/bJfwwVIZ4AkJZBtiuJEmV6PNZZpWTjwLm2jhJlqYRKs0noXTeRbeyrMQzrPwEC0solUSz8LQ3GtJ3jFc8e9Pl8yJKZmrW7OHftG10ZxEfb6iAgejZ9qJAAAAAElFTkSuQmCC)
      }
      .game-cover__later {
        background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAfCAMAAACYj8A5AAAAP1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////9Du/pqAAAAFHRSTlMA8fpqGcLay5+NeWBUPyUSCgU5NzKS4LsAAABnSURBVEjH5dXJDcAwCETRMYm3xI6zuP9a08Q/IJkCnkAgRnqzTaa0h0mVtunTImdUAy0doKUCWk/kLI3EWboCZ6kbZ+kELVXQugNnKfvsq7rcYzePdz+Syz9RXP7V5jOHlsjaLxpk/fkFqxFcxVDMAAAAAElFTkSuQmCC)
      }
    }
    
    @media screen and (max-width:1100px) {
      .game-cover,
      .game-cover__image {
        width: calc((100vw - 20px)/2 - 5px);
        height: calc((100vw - 20px)/2 - 30px)
      }
      .game-cover {
        margin-bottom: 10px
      }
      .game-cover__name {
        background: rgba(0, 0, 0, .3);
        font-size: 14px;
        padding: 7px;
        border-radius: 4px;
        left: 7px;
        bottom: 7px
      }
      .game-cover__later,
      .game-cover__novelty {
        top: 10px;
        background-size: contain;
        width: 51px;
        height: 21px;
        font-size: 9px;
        padding: 5px 0 0 14px
      }
    }
    
    .benefits__wrapper[data-v-2334d768] {
      background-color: rgba(0, 0, 0, .2);
      border-radius: 7px;
      padding: 25px
    }
    
    .benefits__items[data-v-2334d768] {
      display: -webkit-box;
      display: flex
    }
    
    .benefits__item[data-v-2334d768] {
      width: 25%;
      padding-right: 35px
    }
    
    .benefits__text[data-v-2334d768] {
      font-size: 14px;
      line-height: 1.43;
      color: #fff;
      padding-top: 8px
    }
    
    .benefits__dots[data-v-2334d768] {
      display: none
    }
    
    @media screen and (max-width:767px) {
      .benefits[data-v-2334d768] {
        padding: 0 10px
      }
      .benefits__wrapper[data-v-2334d768] {
        padding: 15px
      }
      .benefits__items[data-v-2334d768] {
        overflow: hidden
      }
      .benefits__item[data-v-2334d768] {
        width: 50%;
        display: none;
        padding-right: 25px
      }
      .benefits__item.active[data-v-2334d768] {
        display: block
      }
      .benefits__text[data-v-2334d768] {
        font-size: 12px
      }
      .benefits__dots[data-v-2334d768] {
        display: block;
        margin-top: 15px
      }
    }
    
    .nav_dots[data-v-2d9bc7df] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      list-style: none
    }
    
    .nav_dots li[data-v-2d9bc7df] {
      cursor: pointer;
      width: 9px;
      height: 9px;
      background-color: hsla(0, 0%, 100%, .1);
      border-radius: 30px;
      margin-right: 10px
    }
    
    .nav_dots li.active[data-v-2d9bc7df] {
      background-color: #ffed2a
    }
    
    .table__live {
      height: 650px;
      overflow: hidden
    }
    
    @media screen and (max-width:767px) {
      .table__live .th:nth-child(4),
      .table__live .th:nth-child(6),
      .table__live td:first-child span,
      .table__live td:nth-child(4),
      .table__live td:nth-child(6) {
        display: none!important
      }
      .table__live .th:first-child,
      .table__live td:first-child {
        width: 50px
      }
      .table__live td:first-child:after {
        background: none!important
      }
    }
    
    .table__live[data-v-43846d9d] {
      margin-top: 20px
    }
    
    .table[data-v-85f1a3f0] {
      border-radius: 7px
    }
    
    .table__header[data-v-291dc6c8] {
      width: 100%;
      display: table;
      table-layout: fixed;
      padding: 19px 0;
      border-radius: 7px 7px 0 0;
      position: relative;
      z-index: 2
    }
    
    .table__header_black[data-v-291dc6c8] {
      background: #110028
    }
    
    .table__header_blue[data-v-291dc6c8] {
      background-color: #2c134d
    }
    
    .table__header .thead[data-v-291dc6c8] {
      display: table-header-group;
      vertical-align: middle
    }
    
    .table__header .tr[data-v-291dc6c8] {
      display: table-row
    }
    
    .table__header .th[data-v-291dc6c8] {
      display: table-cell;
      color: #a698af;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      padding-left: 18px
    }
    
    .table__content[data-v-257303ce],
    .table__wrapper[data-v-257303ce] {
      overflow: hidden
    }
    
    .table__content table[data-v-257303ce] {
      width: 100%;
      table-layout: fixed;
      border-spacing: 0
    }
    
    .table__content .table_black[data-v-257303ce] {
      background: #1e0b38
    }
    
    .table__content .table_blue[data-v-257303ce] {
      background: #321656
    }
    
    .table__content tr[data-v-257303ce] {
      height: 50px
    }
    
    .table__animate[data-v-257303ce] {
      -webkit-animation-fill-mode: forwards;
      animation-fill-mode: forwards;
      -webkit-animation-duration: .8s;
      animation-duration: .8s;
      -webkit-animation-timing-function: linear;
      animation-timing-function: linear;
      will-change: transform
    }
    
    .table__animate[data-v-257303ce]:nth-child(2n) {
      -webkit-animation-name: animate-row-2;
      animation-name: animate-row-2
    }
    
    .table__animate[data-v-257303ce]:nth-child(odd) {
      -webkit-animation-name: animate-row;
      animation-name: animate-row
    }
    
    .table__content td[data-v-257303ce] {
      position: relative;
      font-size: 14px;
      padding-left: 18px;
      color: #a698af;
      overflow: hidden;
      white-space: nowrap
    }
    
    .table__content .table_black td[data-v-257303ce] {
      border-bottom: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    .table__content .table_blue td[data-v-257303ce] {
      border-bottom: 1px solid hsla(0, 0%, 100%, .05)
    }
    
    .table__content td[data-v-257303ce]:after {
      width: 50px;
      height: 50px;
      content: "";
      position: absolute;
      right: 0;
      top: 0
    }
    
    .table__content .table_black td[data-v-257303ce]:after {
      background: -webkit-gradient(linear, left top, right top, from(rgba(50, 22, 86, 0)), color-stop(80%, #1e0b38));
      background: linear-gradient(90deg, rgba(50, 22, 86, 0), #1e0b38 80%)
    }
    
    .table__content .table_blue td[data-v-257303ce]:after {
      background: -webkit-gradient(linear, left top, right top, from(rgba(50, 22, 86, 0)), color-stop(80%, #321656));
      background: linear-gradient(90deg, rgba(50, 22, 86, 0), #321656 80%)
    }
    
    .table__content td img[data-v-257303ce] {
      vertical-align: middle;
      margin-right: 7px
    }
    
    @-webkit-keyframes animate-row {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    @keyframes animate-row {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    @-webkit-keyframes animate-row-2 {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    @keyframes animate-row-2 {
      0% {
        -webkit-transform: translateY(-50px);
        transform: translateY(-50px)
      }
    }
    
    .chat[data-v-5a5ddd64] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      width: 306px;
      background-color: hsla(0, 0%, 100%, 0);
      padding: 0 0 38px;
      position: relative;
      height: 100%;
      overflow: hidden
    }
    
    @media (max-width:1200px) {
      .chat[data-v-5a5ddd64] {
        width: 100%;
        height: 100vh;
        height: calc(var(--vh, 1vh)*100);
        padding: 50px 0 0
      }
    }
    
    .chat-footer[data-v-5a5ddd64],
    .chat-online[data-v-5a5ddd64] {
      display: -webkit-box;
      display: flex
    }
    
    .chat-online[data-v-5a5ddd64] {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      font-size: 12px;
      color: #9e8fa9;
      height: 38px;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: center;
      justify-content: center
    }
    
    @media (max-width:1200px) {
      .chat-online[data-v-5a5ddd64] {
        top: 0;
        height: 50px;
        bottom: auto;
        background: #301552;
        border-bottom: 1px solid hsla(0, 0%, 100%, .1)
      }
    }
    
    .chat-online[data-v-5a5ddd64]:before {
      content: "";
      width: 10px;
      height: 9px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMCIgaGVpZ2h0PSI5IiB2aWV3Qm94PSIwIDAgMTAgOSI+CiAgICA8ZyBmaWxsPSIjQTU5N0FFIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxwYXRoIGQ9Ik0zLjgzMyA1aDIuMzM0YTMuMjUgMy4yNSAwIDAgMSAzIDIgMS40NDQgMS40NDQgMCAwIDEtMS4zMzQgMkgyLjE2N0ExLjQ0NCAxLjQ0NCAwIDAgMSAuODMzIDdhMy4yNSAzLjI1IDAgMCAxIDMtMnpNNSA0YzEuMzMzIDAgMi0xLjMzMyAyLTJzMC0yLTItMi0yIDEuMzMzLTIgMiAuNjY3IDIgMiAyeiIvPgogICAgPC9nPgo8L3N2Zz4K) no-repeat 50%;
      background-size: contain;
      margin-right: 3px
    }
    
    .chat-options[data-v-5a5ddd64] {
      -webkit-box-flex: 0;
      flex: none;
      position: relative;
      border-radius: 0 0 7px 7px;
      border: 1px solid hsla(0, 0%, 100%, .1)
    }
    
    @media (max-width:1200px) {
      .chat-options[data-v-5a5ddd64] {
        border: 0;
        border-top: 1px solid hsla(0, 0%, 100%, .1);
        border-radius: 0
      }
    }
    
    #chat-options-input[data-v-5a5ddd64] {
      position: relative
    }
    
    #chat-options-input.disabled[data-v-5a5ddd64] {
      opacity: .5;
      pointer-events: none
    }
    
    .chat-options-input-text[data-v-5a5ddd64] {
      border: 0 solid hsla(0, 0%, 100%, .1);
      background: none;
      font-size: 14px;
      color: #fff;
      width: calc(100% + 20px);
      padding: 11px 60px 0 15px;
      resize: none;
      height: 45px;
      -webkit-transition: height .2s ease-out;
      transition: height .2s ease-out;
      margin-bottom: -3px;
      line-height: 1.65;
      word-wrap: break-word;
      will-change: contents
    }
    
    #chat-options-input[data-v-5a5ddd64] {
      height: 45px
    }
    
    @-moz-document url-prefix() {
      .chat-options-input-text {
        padding-top: 8px
      }
    }
    
    .chat-options-input-text[data-v-5a5ddd64]::-webkit-input-placeholder {
      color: #a698af
    }
    
    .chat-options-input-text[data-v-5a5ddd64]:-ms-input-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::-moz-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::-ms-input-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::-webkit-input-placeholder,
    .chat-options-input-text[data-v-5a5ddd64]::placeholder {
      color: #a698af
    }
    
    .chat-options-input-button[data-v-5a5ddd64] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: start;
      justify-content: flex-start;
      position: absolute;
      bottom: 0;
      right: 0;
      cursor: pointer;
      padding-right: 8px;
      height: 45px
    }
    
    .chat-options-input-button[data-v-5a5ddd64]:before {
      content: "";
      width: 18px;
      height: 19px;
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0ibm9uemVybyIgc3Ryb2tlPSIjQTI5NEFDIiBkPSJNMTYuNTI4IDEwLjgxOGExLjUgMS41IDAgMCAwIDAtMi42MzZMMi44NDQuNzQ1YTEuNSAxLjUgMCAwIDAtMi4wMjUgMi4wNWwzLjA3IDUuNDgzYTIuNSAyLjUgMCAwIDEgMCAyLjQ0NGwtMy4wNyA1LjQ4MmExLjUgMS41IDAgMCAwIDIuMDI1IDIuMDUxbDEzLjY4NC03LjQzN3oiLz4KPC9zdmc+Cg==);
      background-repeat: no-repeat;
      background-position: 50%;
      background-size: contain;
      -webkit-transition: all .2s ease-in-out;
      transition: all .2s ease-in-out
    }
    
    .chat-options-input-button[data-v-5a5ddd64]:hover:before {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTE2Ljc2NyAxMS4yNTdMMy4wODMgMTguNjk0YTIgMiAwIDAgMS0yLjctMi43MzRsMy4wNy01LjQ4M2EyIDIgMCAwIDAgMC0xLjk1NEwuMzgzIDMuMDRhMiAyIDAgMCAxIDIuNy0yLjczNGwxMy42ODQgNy40MzdhMiAyIDAgMCAxIDAgMy41MTR6Ii8+Cjwvc3ZnPgo=)
    }
    
    .chat-options-input-button[data-v-5a5ddd64]:active:before {
      background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9IiNGRkVEMkEiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTE2Ljc2NyAxMS4yNTdMMy4wODMgMTguNjk0YTIgMiAwIDAgMS0yLjctMi43MzRsMy4wNy01LjQ4M2EyIDIgMCAwIDAgMC0xLjk1NEwuMzgzIDMuMDRhMiAyIDAgMCAxIDIuNy0yLjczNGwxMy42ODQgNy40MzdhMiAyIDAgMCAxIDAgMy41MTR6Ii8+Cjwvc3ZnPgo=)
    }
    
    @media (max-width:1200px) {
      .chat-options-input-button[data-v-5a5ddd64]:before {
        background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOSIgdmlld0JveD0iMCAwIDE4IDE5Ij4KICAgIDxwYXRoIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0ibm9uemVybyIgc3Ryb2tlPSIjQTI5NEFDIiBkPSJNMTYuNTI4IDEwLjgxOGExLjUgMS41IDAgMCAwIDAtMi42MzZMMi44NDQuNzQ1YTEuNSAxLjUgMCAwIDAtMi4wMjUgMi4wNWwzLjA3IDUuNDgzYTIuNSAyLjUgMCAwIDEgMCAyLjQ0NGwtMy4wNyA1LjQ4MmExLjUgMS41IDAgMCAwIDIuMDI1IDIuMDUxbDEzLjY4NC03LjQzN3oiLz4KPC9zdmc+Cg==)!important
      }
    }
    
    .chat-access[data-v-5a5ddd64] {
      display: none;
      line-height: 1.33;
      font-size: 12px;
      border-radius: 5px;
      color: #fff;
      background: #ff403d;
      position: absolute;
      bottom: 94px;
      left: 10px;
      right: 10px;
      padding: 5px 11px 7px;
      pointer-events: none
    }
    
    @media (max-width:1200px) {
      .chat-access[data-v-5a5ddd64] {
        bottom: 58px
      }
    }
    
    .chat-access.show[data-v-5a5ddd64] {
      display: block;
      -webkit-animation: showSystem-data-v-5a5ddd64 .2s ease-out forwards;
      animation: showSystem-data-v-5a5ddd64 .2s ease-out forwards
    }
    
    .chat-access.hide[data-v-5a5ddd64] {
      display: block;
      -webkit-animation: hideSystem-data-v-5a5ddd64 .2s ease-out forwards;
      animation: hideSystem-data-v-5a5ddd64 .2s ease-out forwards
    }
    
    .chat-messages[data-v-5a5ddd64] {
      -webkit-box-flex: 1;
      flex: auto;
      -webkit-transition: all .3s;
      transition: all .3s;
      min-height: 100px;
      display: -webkit-box;
      display: flex;
      height: 120px;
      -webkit-box-orient: vertical;
      -webkit-box-direction: reverse;
      flex-direction: column-reverse;
      position: relative;
      padding: 0 11px;
      border-radius: 7px 7px 0 0;
      border: 1px solid hsla(0, 0%, 100%, .1);
      border-bottom: 0
    }
    
    @media (max-width:1200px) {
      .chat-messages[data-v-5a5ddd64] {
        border-radius: 0;
        border: 0
      }
    }
    
    .chat-messages-container[data-v-5a5ddd64] {
      position: relative;
      margin-right: -15px;
      padding-right: 15px;
      height: 100%;
      overflow: scroll;
      overflow-anchor: none;
      touch-action: auto
    }
    
    @-webkit-keyframes showSystem-data-v-5a5ddd64 {
      0% {
        opacity: 0
      }
      to {
        opacity: 1
      }
    }
    
    @keyframes showSystem-data-v-5a5ddd64 {
      0% {
        opacity: 0
      }
      to {
        opacity: 1
      }
    }
    
    @-webkit-keyframes hideSystem-data-v-5a5ddd64 {
      0% {
        opacity: 1
      }
      to {
        opacity: 0
      }
    }
    
    @keyframes hideSystem-data-v-5a5ddd64 {
      0% {
        opacity: 1
      }
      to {
        opacity: 0
      }
    }
    
    .chat__close[data-v-5a5ddd64] {
      display: none
    }
    
    @media screen and (max-width:767px) {
      .chat__close[data-v-5a5ddd64] {
        position: absolute;
        right: 16px;
        top: 16px;
        display: block;
        width: 16px;
        height: 16px;
        border-radius: 4px;
        display: -webkit-box;
        display: flex;
        -webkit-box-pack: center;
        justify-content: center;
        -webkit-box-align: center;
        align-items: center;
        cursor: pointer;
        -webkit-transition: all .3s;
        transition: all .3s
      }
      .chat__close svg[data-v-5a5ddd64] {
        width: 17px;
        height: 17px;
        fill: hsla(0, 0%, 100%, .3);
        color: hsla(0, 0%, 100%, .3)
      }
      @media screen and (min-width:720px) {
        .chat__close:hover svg[data-v-5a5ddd64] {
          fill: #fff;
          color: #fff
        }
      }
      .chat__close:active svg[data-v-5a5ddd64] {
        fill: #1d0130;
        color: #1d0130
      }
      .chat__close svg path[data-v-5a5ddd64] {
        fill-opacity: 1
      }
    }
    
    .chat-show-rules[data-v-5a5ddd64] {
      cursor: pointer;
      display: inline-block;
      margin-left: 20px
    }
    
    .footer__wrap[data-v-28d2291f] {
      max-width: 1200px;
      padding: 15px 30px;
      margin: 0 auto
    }
    
    .footer__row[data-v-28d2291f] {
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .footer__row[data-v-28d2291f],
    .footer__sitename[data-v-28d2291f] {
      display: -webkit-box;
      display: flex
    }
    
    .footer__sitename[data-v-28d2291f] {
      font-size: 14px;
      font-weight: 700;
      color: #fff;
      -webkit-box-align: center;
      align-items: center
    }
    
    .footer__adverts[data-v-28d2291f] {
      font-size: 14px;
      line-height: 2.08;
      color: #fff
    }
    
    .footer__adverts a[data-v-28d2291f] {
      font-size: 14px!important
    }
    
    .footer__col[data-v-28d2291f]:last-child {
      display: -webkit-box;
      display: flex;
      padding-top: 5px;
      margin-right: 0
    }
    
    .footer a[data-v-28d2291f] {
      font-size: 12px;
      line-height: 1.33
    }
    
    .footer a[data-v-28d2291f]:active {
      color: #fff
    }
    
    .footer__col a[data-v-28d2291f] {
      margin-right: 30px
    }
    
    .footer__col:last-child a[data-v-28d2291f]:first-child {
      display: inline-block
    }
    
    .footer__button[data-v-28d2291f] {
      width: 32px;
      height: 32px;
      border-radius: 30px;
      background-repeat: no-repeat;
      background-position: 50%;
      margin-right: 10px!important
    }
    
    .vk[data-v-28d2291f] {
      background-image: url(/images/footer/vk_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-28d2291f] {
        background-image: url(/images/footer/vk_default@2x.png)
      }
    }
    
    .vk[data-v-28d2291f] {
      background-image: -webkit-image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      --moz-background-image: url(/images/footer/vk_default.png)
    }
    
    .vk[data-v-28d2291f]:active,
    .vk[data-v-28d2291f]:hover {
      background-image: url(/images/footer/vk_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-28d2291f]:active,
      .vk[data-v-28d2291f]:hover {
        background-image: url(/images/footer/vk_active@2x.png)
      }
    }
    
    .vk[data-v-28d2291f]:active,
    .vk[data-v-28d2291f]:hover {
      background-image: -webkit-image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x)
    }
    
    .telegram[data-v-28d2291f] {
      background-image: url(/images/footer/telegram_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-28d2291f] {
        background-image: url(/images/footer/telegram_default@2x.png)
      }
    }
    
    .telegram[data-v-28d2291f] {
      background-image: -webkit-image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x)
    }
    
    .telegram[data-v-28d2291f]:active,
    .telegram[data-v-28d2291f]:hover {
      background-image: url(/images/footer/telegram_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-28d2291f]:active,
      .telegram[data-v-28d2291f]:hover {
        background-image: url(/images/footer/telegram_active@2x.png)
      }
    }
    
    .telegram[data-v-28d2291f]:active,
    .telegram[data-v-28d2291f]:hover {
      background-image: -webkit-image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x)
    }
    
    @-moz-document url-prefix() {
      .vk {
        background: url(/images/footer/vk_default.png) 50% no-repeat
      }
      .vk:active,
      .vk:hover {
        background: url(/images/footer/vk_active.png) 50% no-repeat
      }
      .telegram {
        background: url(/images/footer/telegram_default.png) 50% no-repeat
      }
      .telegram:active,
      .telegram:hover {
        background: url(/images/footer/telegram_active.png) 50% no-repeat
      }
    }
    
    .footer__button.telegram[data-v-28d2291f]:hover,
    .footer__button.vk[data-v-28d2291f]:hover {
      background-color: #fff
    }
    
    .footer__button.telegram[data-v-28d2291f]:active,
    .footer__button.vk[data-v-28d2291f]:active {
      background-color: #ffed2a
    }
    
    .footer__button.vk[data-v-28d2291f] {
      background-color: #4a76a8
    }
    
    .footer__button.telegram[data-v-28d2291f] {
      background-color: #31a8df
    }
    
    .popup__content[data-v-1ddfe4aa] {
      margin: 35px 0 0;
      padding: 10px 50px;
      text-align: center
    }
    
    .popup__content p[data-v-1ddfe4aa] {
      font-size: 16px;
      line-height: 1.44;
      color: #fff;
      margin-bottom: 21px;
      text-align: center
    }
    
    .popup__content button[data-v-1ddfe4aa] {
      width: 186px
    }
    
    .popup__image[data-v-1ddfe4aa] {
      margin-bottom: 22px;
      text-align: center
    }
    
    .v--modal {
      border: 1px solid hsla(0, 0%, 100%, .1)!important;
      background-color: rgba(41, 26, 67, .85)!important;
      padding: 18px 0 26px!important
    }
    
    @media screen and (max-width:719px) {
      .v--modal {
        padding: 18px 0 20px!important
      }
    }
    
    .v--modal-overlay {
      background: rgba(0, 0, 0, .95)!important
    }
    
    .popup__header[data-v-a21c11a8] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
      justify-content: space-between;
      -webkit-box-align: center;
      align-items: center;
      border-bottom: 1px solid hsla(0, 0%, 100%, .15);
      margin-bottom: 25px;
      padding: 0 22px 21px
    }
    
    @media screen and (max-width:719px) {
      .popup__header[data-v-a21c11a8] {
        padding: 0 10px 16px;
        margin-bottom: 15px
      }
    }
    
    .popup__title[data-v-a21c11a8] {
      font-size: 26px;
      font-weight: 800;
      color: #fff
    }
    
    @media screen and (max-width:719px) {
      .popup__title[data-v-a21c11a8] {
        font-size: 20px
      }
    }
    
    .popup__close[data-v-a21c11a8] {
      width: 16px;
      height: 16px;
      border-radius: 4px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      cursor: pointer;
      -webkit-transition: all .3s;
      transition: all .3s
    }
    
    .popup__close svg[data-v-a21c11a8] {
      width: 17px;
      height: 17px;
      fill: hsla(0, 0%, 100%, .3);
      color: hsla(0, 0%, 100%, .3)
    }
    
    @media screen and (min-width:720px) {
      .popup__close:hover svg[data-v-a21c11a8] {
        fill: #fff;
        color: #fff
      }
    }
    
    .popup__close:active svg[data-v-a21c11a8] {
      fill: #1d0130;
      color: #1d0130
    }
    
    .popup__close svg path[data-v-a21c11a8] {
      fill-opacity: 1
    }
    
    .giftcode__form[data-v-2ca6d62e] {
      width: 302px;
      margin: 60px auto 25px
    }
    
    .giftcode__hint[data-v-2ca6d62e] {
      text-align: center;
      max-width: 400px;
      color: #a698af;
      font-size: 12px;
      line-height: 1.55;
      margin: 0 auto 25px
    }
    
    .giftcode__footer[data-v-2ca6d62e] {
      height: 125px;
      position: relative;
      top: 26px;
      background-color: hsla(0, 0%, 100%, .09804)
    }
    
    .giftcide__image[data-v-2ca6d62e] {
      position: absolute;
      z-index: 2;
      left: 20px;
      top: -9px
    }
    
    .giftcode__subscribe[data-v-2ca6d62e] {
      margin-left: 185px
    }
    
    .giftcode__subscribe span[data-v-2ca6d62e] {
      display: inline-block;
      color: #fff;
      font-size: 16px;
      font-weight: 700;
      margin-top: 15px
    }
    
    .giftcode__links[data-v-2ca6d62e] {
      margin-top: 15px
    }
    
    .footer__button[data-v-2ca6d62e] {
      display: inline-block;
      width: 48px;
      height: 48px;
      border-radius: 30px;
      background-repeat: no-repeat;
      background-position: 50%;
      margin-right: 10px!important
    }
    
    @media screen and (max-width:767px) {
      .giftcode__form[data-v-2ca6d62e] {
        width: 100%;
        margin: 30px 0 25px;
        padding: 0 15px
      }
      .giftcide__image[data-v-2ca6d62e] {
        left: 0
      }
      .giftcode__subscribe span[data-v-2ca6d62e] {
        font-size: 12px;
        line-height: normal
      }
      .footer__button[data-v-2ca6d62e] {
        width: 32px;
        height: 32px
      }
    }
    
    .vk[data-v-2ca6d62e] {
      background-image: url(/images/footer/vk_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-2ca6d62e] {
        background-image: url(/images/footer/vk_default@2x.png)
      }
    }
    
    .vk[data-v-2ca6d62e] {
      background-image: -webkit-image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      --moz-background-image: url(/images/footer/vk_default.png)
    }
    
    .vk[data-v-2ca6d62e]:active,
    .vk[data-v-2ca6d62e]:hover {
      background-image: url(/images/footer/vk_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-2ca6d62e]:active,
      .vk[data-v-2ca6d62e]:hover {
        background-image: url(/images/footer/vk_active@2x.png)
      }
    }
    
    .vk[data-v-2ca6d62e]:active,
    .vk[data-v-2ca6d62e]:hover {
      background-image: -webkit-image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x)
    }
    
    .telegram[data-v-2ca6d62e] {
      background-image: url(/images/footer/telegram_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-2ca6d62e] {
        background-image: url(/images/footer/telegram_default@2x.png)
      }
    }
    
    .telegram[data-v-2ca6d62e] {
      background-image: -webkit-image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x)
    }
    
    .telegram[data-v-2ca6d62e]:active,
    .telegram[data-v-2ca6d62e]:hover {
      background-image: url(/images/footer/telegram_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-2ca6d62e]:active,
      .telegram[data-v-2ca6d62e]:hover {
        background-image: url(/images/footer/telegram_active@2x.png)
      }
    }
    
    .telegram[data-v-2ca6d62e]:active,
    .telegram[data-v-2ca6d62e]:hover {
      background-image: -webkit-image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x)
    }
    
    @-moz-document url-prefix() {
      .vk {
        background: url(/images/footer/vk_default.png) 50% no-repeat
      }
      .vk:active,
      .vk:hover {
        background: url(/images/footer/vk_active.png) 50% no-repeat
      }
      .telegram {
        background: url(/images/footer/telegram_default.png) 50% no-repeat
      }
      .telegram:active,
      .telegram:hover {
        background: url(/images/footer/telegram_active.png) 50% no-repeat
      }
    }
    
    .footer__button.telegram[data-v-2ca6d62e]:hover,
    .footer__button.vk[data-v-2ca6d62e]:hover {
      background-color: #fff
    }
    
    .footer__button.telegram[data-v-2ca6d62e]:active,
    .footer__button.vk[data-v-2ca6d62e]:active {
      background-color: #ffed2a
    }
    
    .footer__button.vk[data-v-2ca6d62e] {
      background-color: #4a76a8
    }
    
    .footer__button.telegram[data-v-2ca6d62e] {
      background-color: #31a8df
    }
    
    .content[data-v-0287a918] {
      margin: 35px 0 0;
      padding: 20px
    }
    
    .content[data-v-0287a918],
    p[data-v-0287a918] {
      text-align: center
    }
    
    p[data-v-0287a918] {
      font-size: 16px;
      line-height: 24px;
      margin-top: 5px;
      margin-bottom: 30px
    }
    
    h3[data-v-0287a918],
    p[data-v-0287a918] {
      color: #fff
    }
    
    h3[data-v-0287a918] {
      margin-top: 15px;
      font-size: 20px;
      line-height: 28px
    }
    
    .content img[data-v-0287a918] {
      width: 120px;
      height: 120px
    }
    
    .content button[data-v-0287a918] {
      max-width: 200px
    }
    
    .popup__content[data-v-af6c4662] {
      margin: 35px 0 0;
      padding: 20px
    }
    
    .popup__content p[data-v-af6c4662] {
      font-size: 16px;
      line-height: 1.44;
      color: #fff;
      margin-bottom: 21px;
      text-align: center
    }
    
    .popup__image[data-v-af6c4662] {
      margin-bottom: 22px;
      text-align: center
    }
    
    .chat_mobile__wrapper .v--modal {
      position: relative;
      padding: 0!important
    }
  </style>
  <style data-vue-ssr-id="0e783494:0">
    .v--modal-block-scroll {
      overflow: hidden;
      width: 100vw;
    }
    
    .v--modal-overlay {
      position: fixed;
      box-sizing: border-box;
      left: 0;
      top: 0;
      width: 100%;
      height: 100vh;
      background: rgba(0, 0, 0, 0.2);
      z-index: 999;
      opacity: 1;
    }
    
    .v--modal-overlay.scrollable {
      height: 100%;
      min-height: 100vh;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }
    
    .v--modal-overlay .v--modal-background-click {
      width: 100%;
      min-height: 100%;
      height: auto;
    }
    
    .v--modal-overlay .v--modal-box {
      position: relative;
      overflow: hidden;
      box-sizing: border-box;
    }
    
    .v--modal-overlay.scrollable .v--modal-box {
      margin-bottom: 2px;
    }
    
    .v--modal {
      background-color: white;
      text-align: left;
      border-radius: 3px;
      box-shadow: 0 20px 60px -2px rgba(27, 33, 58, 0.4);
      padding: 0;
    }
    
    .v--modal.v--modal-fullscreen {
      width: 100vw;
      height: 100vh;
      margin: 0;
      left: 0;
      top: 0;
    }
    
    .v--modal-top-right {
      display: block;
      position: absolute;
      right: 0;
      top: 0;
    }
    
    .overlay-fade-enter-active,
    .overlay-fade-leave-active {
      transition: all 0.2s;
    }
    
    .overlay-fade-enter,
    .overlay-fade-leave-active {
      opacity: 0;
    }
    
    .nice-modal-fade-enter-active,
    .nice-modal-fade-leave-active {
      transition: all 0.4s;
    }
    
    .nice-modal-fade-enter,
    .nice-modal-fade-leave-active {
      opacity: 0;
      transform: translateY(-20px);
    }
  </style>
  <style type="text/css">
    .__nuxt-error-page {
      padding: 1rem;
      background: #f7f8fb;
      color: #47494e;
      text-align: center;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      font-family: sans-serif;
      font-weight: 100!important;
      -ms-text-size-adjust: 100%;
      -webkit-text-size-adjust: 100%;
      -webkit-font-smoothing: antialiased;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0
    }
    
    .__nuxt-error-page .error {
      max-width: 450px
    }
    
    .__nuxt-error-page .title {
      font-size: 1.5rem;
      margin-top: 15px;
      color: #47494e;
      margin-bottom: 8px
    }
    
    .__nuxt-error-page .description {
      color: #7f828b;
      line-height: 21px;
      margin-bottom: 10px
    }
    
    .__nuxt-error-page a {
      color: #7f828b!important;
      text-decoration: none
    }
    
    .__nuxt-error-page .logo {
      position: fixed;
      left: 12px;
      bottom: 12px
    }
  </style>
  <style type="text/css">
    button[data-v-763fb338] {
      cursor: pointer;
      outline: none;
      width: 100%;
      height: 36px;
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      background: transparent;
      border-radius: 5px;
      border: 2px solid hsla(0, 0%, 100%, .2);
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      -webkit-box-pack: center;
      justify-content: center;
      line-height: 18px;
      padding: 0 20px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    button[data-v-763fb338]:hover {
      border: 2px solid #fff
    }
    
    button[data-v-763fb338]:active {
      border: 2px solid #ffed2a
    }
    
    .is__light[data-v-763fb338] {
      border: none;
      background-color: hsla(0, 0%, 100%, .2)
    }
    
    .is__light[data-v-763fb338]:hover {
      border: none;
      color: #3f2652;
      background-color: #fff
    }
    
    .is__light[data-v-763fb338]:active {
      border: none;
      color: #3f2652;
      background-color: #ffed2a
    }
  </style>
  <style type="text/css">
    .login-buttons[data-v-9c33f3e2] {
      display: -webkit-box;
      display: flex
    }
    
    .login-buttons button[data-v-9c33f3e2]:first-child {
      margin-right: 10px
    }
  </style>
  <style type="text/css">
    @media (max-width:1199px) {
      .login-buttons[data-v-9c33f3e2] {
        max-width: 200px
      }
      .login-buttons button[data-v-9c33f3e2] {
        width: auto
      }
    }
  </style>
  <style type="text/css">
    .footer__wrap[data-v-64bbb08d] {
      padding: 15px;
      margin: 0 auto
    }
    
    .footer__row[data-v-64bbb08d] {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .footer__row[data-v-64bbb08d]:first-child {
      padding-bottom: 10px;
      margin-bottom: 10px;
      border-bottom: 1px solid hsla(0, 0%, 100%, .09804)
    }
    
    .footer__col[data-v-64bbb08d] {
      width: 50%
    }
    
    .footer__sitename[data-v-64bbb08d] {
      font-size: 14px;
      font-weight: 700;
      color: #fff
    }
    
    .footer__adverts[data-v-64bbb08d] {
      font-size: 14px;
      line-height: 2.08;
      color: #fff
    }
    
    .footer__adverts a[data-v-64bbb08d] {
      font-size: 14px!important
    }
    
    .footer__col[data-v-64bbb08d]:last-child {
      padding-top: 5px;
      margin-right: 0
    }
    
    .footer a[data-v-64bbb08d] {
      font-size: 12px;
      line-height: 1.33
    }
    
    .footer a[data-v-64bbb08d]:active {
      color: #fff
    }
    
    .footer__col a[data-v-64bbb08d] {
      margin-right: 30px
    }
    
    .footer__col:last-child a[data-v-64bbb08d]:first-child {
      display: inline-block
    }
    
    .footer__buttons[data-v-64bbb08d] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    .footer__button[data-v-64bbb08d] {
      width: 32px;
      height: 32px;
      border-radius: 30px;
      background-repeat: no-repeat;
      background-position: 50%;
      margin-right: 10px!important
    }
    
    .vk[data-v-64bbb08d] {
      background-image: url(/images/footer/vk_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-64bbb08d] {
        background-image: url(/images/footer/vk_default@2x.png)
      }
    }
    
    .vk[data-v-64bbb08d] {
      background-image: -webkit-image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_default.png") 1x, url("/images/footer/vk_default@2x.png") 2x)
    }
    
    .vk[data-v-64bbb08d]:active,
    .vk[data-v-64bbb08d]:hover {
      background-image: url(/images/footer/vk_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .vk[data-v-64bbb08d]:active,
      .vk[data-v-64bbb08d]:hover {
        background-image: url(/images/footer/vk_active@2x.png)
      }
    }
    
    .vk[data-v-64bbb08d]:active,
    .vk[data-v-64bbb08d]:hover {
      background-image: -webkit-image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/vk_active.png") 1x, url("/images/footer/vk_active@2x.png") 2x)
    }
    
    .telegram[data-v-64bbb08d] {
      background-image: url(/images/footer/telegram_default.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-64bbb08d] {
        background-image: url(/images/footer/telegram_default@2x.png)
      }
    }
    
    .telegram[data-v-64bbb08d] {
      background-image: -webkit-image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_default.png") 1x, url("/images/footer/telegram_default@2x.png") 2x)
    }
    
    .telegram[data-v-64bbb08d]:active,
    .telegram[data-v-64bbb08d]:hover {
      background-image: url(/images/footer/telegram_active.png)
    }
    
    @media (-webkit-min-device-pixel-ratio:2),
    (min-resolution:192dpi) {
      .telegram[data-v-64bbb08d]:active,
      .telegram[data-v-64bbb08d]:hover {
        background-image: url(/images/footer/telegram_active@2x.png)
      }
    }
    
    .telegram[data-v-64bbb08d]:active,
    .telegram[data-v-64bbb08d]:hover {
      background-image: -webkit-image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x);
      background-image: image-set(url("/images/footer/telegram_active.png") 1x, url("/images/footer/telegram_active@2x.png") 2x)
    }
    
    @-moz-document url-prefix() {
      .vk {
        background: url(/images/footer/vk_default.png) 50% no-repeat
      }
      .vk:active,
      .vk:hover {
        background: url(/images/footer/vk_active.png) 50% no-repeat
      }
      .telegram {
        background: url(/images/footer/telegram_default.png) 50% no-repeat
      }
      .telegram:active,
      .telegram:hover {
        background: url(/images/footer/telegram_active.png) 50% no-repeat
      }
    }
    
    .footer__button.telegram[data-v-64bbb08d]:hover,
    .footer__button.vk[data-v-64bbb08d]:hover {
      background-color: #fff
    }
    
    .footer__button.telegram[data-v-64bbb08d]:active,
    .footer__button.vk[data-v-64bbb08d]:active {
      background-color: #ffed2a
    }
    
    .footer__button.vk[data-v-64bbb08d] {
      background-color: #4a76a8
    }
    
    .footer__button.telegram[data-v-64bbb08d] {
      background-color: #31a8df
    }
  </style>
  <style type="text/css">
    label[data-v-8924fe4c] {
      font-size: 14px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 12px;
      display: block
    }
    
    label small[data-v-8924fe4c] {
      display: block;
      font-size: 58%;
      color: grey;
      margin-top: 10px
    }
    
    span.error[data-v-8924fe4c] {
      display: inline-block;
      min-height: 25px;
      border-radius: 5px;
      background-color: #ff403d;
      -webkit-box-align: center;
      align-items: center;
      font-size: 13px;
      color: #fff;
      margin-top: 10px;
      padding: 5px 10px
    }
    
    .form__item[data-v-8924fe4c]:not(:last-child) {
      margin-bottom: 20px
    }
    
    @media (max-width:767px) {
      .flex__xs[data-v-8924fe4c] {
        display: -webkit-box;
        display: flex;
        -webkit-box-align: center;
        align-items: center;
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        flex-direction: row;
        -webkit-box-pack: justify;
        justify-content: space-between
      }
      .flex__xs label[data-v-8924fe4c] {
        margin-bottom: 0;
        margin-right: 15px
      }
      label.hidden__xs[data-v-8924fe4c] {
        display: none
      }
      .form__item[data-v-8924fe4c]:not(:last-child) {
        margin-bottom: 15px
      }
    }
  </style>
  <style type="text/css">
    input[data-v-272bb7bf] {
      width: 100%;
      height: 50px;
      padding: 11px 14px;
      border-radius: 7px;
      border: 1px solid transparent;
      background-color: #000;
      outline: none;
      font-size: 18px;
      color: #fff
    }
    
    @media screen and (min-width:720px) {
      input[data-v-272bb7bf]:not(: focus):hover {
        border: 1px solid hsla(0, 0%, 100%, .75)
      }
    }
    
    input[data-v-272bb7bf]:focus {
      box-shadow: 0 0 9px 0 rgba(255, 237, 42, .35);
      border: 1px solid #ffed2a;
      outline: none;
      border-radius: 4px
    }
    
    input.error[data-v-272bb7bf] {
      box-shadow: 0 0 9px 0 rgba(255, 103, 100, .6);
      border: 1px solid #ff403d
    }
  </style>
  <style type="text/css">
    button[data-v-b1f23028] {
      width: 100%;
      height: 50px;
      border-radius: 5px;
      box-shadow: inset 0 -3px 0 0 rgba(0, 0, 0, .24);
      background-image: -webkit-gradient(linear, left top, left bottom, from(#ffed2a), to(#ffdc2a));
      background-image: linear-gradient(#ffed2a, #ffdc2a);
      font-size: 18px;
      font-weight: 700;
      color: #230b36;
      cursor: pointer;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      border: none;
      outline: none
    }
    
    @media screen and (min-width:720px) {
      button[data-v-b1f23028]:not(: disabled):not(.loading):hover {
        background-image: -webkit-gradient(linear, left top, left bottom, from(#ffcb00), to(#ffaf00));
        background-image: linear-gradient(#ffcb00, #ffaf00)
      }
    }
    
    button[data-v-b1f23028]:not(:disabled):not(.loading):active {
      box-shadow: inset 0 3px 0 0 rgba(0, 0, 0, .24);
      background-image: none;
      background-color: #fb0
    }
    
    .disabled[data-v-b1f23028] {
      background-color: #2f2149;
      box-shadow: none;
      background-image: none;
      color: hsla(0, 0%, 100%, .15)
    }
    
    .loading[data-v-b1f23028] {
      font-size: 0!important;
      background: #fb0;
      box-shadow: none;
      border: none;
      cursor: default
    }
    
    .loading svg[data-v-b1f23028] {
      display: none
    }
    
    .loading[data-v-b1f23028]:after {
      display: inline-block;
      content: "";
      width: 20px;
      height: 20px;
      border-radius: 50%;
      border: 4px solid rgba(42, 22, 58, .2);
      border-top-color: #231230;
      -webkit-animation: loader_animation-data-v-b1f23028 .8s linear infinite;
      animation: loader_animation-data-v-b1f23028 .8s linear infinite
    }
    
    @-webkit-keyframes loader_animation-data-v-b1f23028 {
      0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg)
      }
      to {
        -webkit-transform: rotate(1turn);
        transform: rotate(1turn)
      }
    }
    
    @keyframes loader_animation-data-v-b1f23028 {
      0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg)
      }
      to {
        -webkit-transform: rotate(1turn);
        transform: rotate(1turn)
      }
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:320px) {
      .recaptcha__container iframe[data-v-843d635e] {
        transform: scale(.95);
        -webkit-transform: scale(.95);
        -webkit-transform-origin: 0 0;
        transform-origin: 0 0
      }
    }
  </style>
  <style type="text/css">
    form[data-v-843d635e] {
      padding: 0 100px
    }
    
    @media screen and (max-width:719px) {
      form[data-v-843d635e] {
        padding: 0 15px
      }
    }
    
    .accept-terms[data-v-843d635e] {
      margin-bottom: 20px;
      font-size: 12px;
      color: #fff
    }
    
    .footer[data-v-843d635e] {
      margin-top: 30px;
      border-top: 1px solid hsla(0, 0%, 100%, .15);
      text-align: center
    }
    
    .footer__link[data-v-843d635e] {
      font-size: 14px;
      color: #ffed2a;
      cursor: pointer;
      position: relative;
      top: 13px
    }
    
    @media screen and (max-width:719px) {
      .footer__link[data-v-843d635e] {
        top: 10px
      }
    }
  </style>
  <style type="text/css">
    form[data-v-89df668a] {
      padding: 0 100px
    }
    
    @media screen and (max-width:719px) {
      form[data-v-89df668a] {
        padding: 0 15px
      }
    }
    
    .footer[data-v-89df668a] {
      margin-top: 30px;
      border-top: 1px solid hsla(0, 0%, 100%, .15);
      text-align: center
    }
    
    .footer__link[data-v-89df668a] {
      font-size: 14px;
      color: #ffed2a;
      cursor: pointer;
      position: relative;
      top: 13px
    }
    
    @media screen and (max-width:719px) {
      .footer__link[data-v-89df668a] {
        top: 10px
      }
    }
  </style>
  <style type="text/css">
    .chat-message__user {
      color: #a698af
    }
    
    .chat-message__user_admin:before {
      display: inline-block;
      content: "";
      width: 11px;
      height: 11px;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNjI4YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY4LjEzMXYuMjY1Yy0uOCAxLjAxMi0xLjkyMyAxLjI1LTIuOTAxLjk1OEEyLjk0MyAyLjk0MyAwIDAgMSAuMDA5IDYuMjlDLjI0NyAzLjA1NCA1IDMgNS41LjIyMiA2IDMgMTAuODE1IDMuMTE0IDEwLjk5NSA2LjI5MmMuMTU2IDIuNzgzLTMuMTA0IDQuMzgyLTQuOTkxIDIuMDQ5eiIvPgo8L3N2Zz4K) no-repeat 50%;
      margin-right: 4px
    }
    
    .chat-message__text {
      margin-left: 3px;
      word-wrap: break-word
    }
  </style>
  <style type="text/css">
    .chat-message-withdraw__user {
      color: #a698af
    }
  </style>
  <style type="text/css">
    .chat-message-game__number {
      font-size: 12px;
      color: #a698af;
      margin-top: 10px;
      margin-bottom: 10px
    }
    
    .chat-message-game__values {
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .chat-message-game__panel {
      width: 80px;
      padding: 8px 10px;
      background-color: #361c57;
      font-size: 13px;
      color: #fff;
      border-radius: 5px
    }
    
    .chat-message-game__panel span {
      display: block;
      color: #a597af;
      font-size: 12px;
      margin-bottom: 3px
    }
  </style>
  <style type="text/css">
    .chat-rain[data-v-147d5b6e] {
      position: relative;
      padding-top: 30px;
      line-height: 1.29
    }
    
    .chat-rain[data-v-147d5b6e]:before {
      content: "";
      height: 17px;
      position: absolute;
      left: 0;
      right: 0;
      top: 5px;
      background: url(/_nuxt/img/fc3c791.png) space 0;
      background-size: contain
    }
    
    .chat-rain__user[data-v-147d5b6e] {
      color: #a293ac;
      margin-right: 3px
    }
  </style>
  <style type="text/css">
    .chat-rules__header {
      color: #a698af;
      margin-bottom: 5px
    }
    
    .chat-rules__content {
      color: #fff;
      list-style: none;
      padding: 0
    }
    
    .chat-rules__content li {
      line-height: 1.71
    }
    
    .chat-rules__content li:before {
      content: "";
      width: 11px;
      height: 11px;
      display: inline-block;
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNBNjk4QUYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNDA2YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY3LjkwOXYuMjY1Yy0uOCAxLjAxMi0xLjkyMyAxLjI1LTIuOTAxLjk1OGEyLjk0MyAyLjk0MyAwIDAgMS0yLjA5LTMuMDYzQy4yNDcgMi44MzIgNSAyLjc3OCA1LjUgMCA2IDIuNzc4IDEwLjgxNSAyLjg5MiAxMC45OTUgNi4wNjljLjE1NiAyLjc4NC0zLjEwNCA0LjM4My00Ljk5MSAyLjA1eiIvPgo8L3N2Zz4K) no-repeat 0 0;
      margin-right: 6px
    }
  </style>
  <style type="text/css">
    .chat-message {
      width: 100%;
      padding: 10px 15px 12px;
      margin-bottom: 10px;
      line-height: 1.14;
      border-radius: 5px;
      color: #fff;
      font-size: 14px;
      background-color: hsla(0, 0%, 100%, .03);
      -webkit-transition: background-color .2s ease-in-out;
      transition: background-color .2s ease-in-out
    }
    
    .chat-message_system {
      background-color: #301552
    }
  </style>
  <script charset="utf-8" src="/_nuxt/709607343198bfc58ab1.js"></script>
  <script charset="utf-8" src="/_nuxt/ea2b21f4eda7cb55fc86.js"></script>
  <style type="text/css">
    .content__container[data-v-1aec7022] {
      width: 100%
    }
    
    .subtitle[data-v-1aec7022] {
      font-size: 23px;
      font-weight: 800;
      line-height: 1.39
    }
    
    @media screen and (max-width:719px) {
      .subtitle[data-v-1aec7022] {
        font-size: 19px
      }
    }
    
    .terms[data-v-1aec7022] {
      border: 1px solid #000;
      background-color: #291a43;
      padding: 18px 15px 15px 28px;
      margin-bottom: 13px;
      border-radius: 7px
    }
    
    @media screen and (max-width:719px) {
      .terms[data-v-1aec7022] {
        padding: 16px 10px 12px
      }
    }
    
    .terms__subtitle[data-v-1aec7022] {
      color: #ffed2a;
      margin-bottom: 19px
    }
    
    .terms__number[data-v-1aec7022] {
      min-width: 33px;
      height: 22px;
      border-radius: 4px;
      background-color: #ffed2a;
      font-size: 14px;
      font-weight: 700;
      color: #1d0130;
      margin-bottom: 3px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      padding: 6px
    }
    
    .terms__text[data-v-1aec7022] {
      font-size: 14px;
      line-height: 1.5;
      color: #fff;
      width: 750px;
      max-width: 100%
    }
    
    .terms__group[data-v-1aec7022]:not(:last-child) {
      margin-bottom: 47px
    }
    
    @media screen and (max-width:719px) {
      .terms__group[data-v-1aec7022]:not(: last-child) {
        margin-bottom: 31px
      }
    }
    
    @media screen and (max-width:719px) {
      .terms__group:last-child .terms__item[data-v-1aec7022]:last-child {
        margin-bottom: 10px
      }
    }
    
    .terms__item[data-v-1aec7022] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-align: start;
      align-items: flex-start;
      margin-bottom: 19px
    }
  </style>
  <style type="text/css">
    .content__container[data-v-17b23741] {
      width: 100%
    }
    
    .subtitle[data-v-17b23741] {
      font-size: 23px;
      font-weight: 800;
      line-height: 1.39
    }
    
    @media screen and (max-width:719px) {
      .subtitle[data-v-17b23741] {
        font-size: 19px
      }
    }
    
    .terms[data-v-17b23741] {
      border: 1px solid #000;
      background-color: #291a43;
      padding: 18px 15px 15px 28px;
      margin-bottom: 13px;
      border-radius: 7px
    }
    
    @media screen and (max-width:719px) {
      .terms[data-v-17b23741] {
        padding: 16px 10px 12px
      }
    }
    
    .terms__subtitle[data-v-17b23741] {
      color: #ffed2a;
      margin-bottom: 19px
    }
    
    .terms__number[data-v-17b23741] {
      min-width: 33px;
      height: 22px;
      border-radius: 4px;
      background-color: #ffed2a;
      font-size: 14px;
      font-weight: 700;
      color: #1d0130;
      margin-bottom: 3px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      padding: 6px
    }
    
    .terms__text[data-v-17b23741] {
      font-size: 14px;
      line-height: 1.5;
      color: #fff;
      width: 750px;
      max-width: 100%
    }
    
    .terms__group[data-v-17b23741]:not(:last-child) {
      margin-bottom: 47px
    }
    
    @media screen and (max-width:719px) {
      .terms__group[data-v-17b23741]:not(: last-child) {
        margin-bottom: 31px
      }
    }
    
    @media screen and (max-width:719px) {
      .terms__group:last-child .terms__item[data-v-17b23741]:last-child {
        margin-bottom: 10px
      }
    }
    
    .terms__item[data-v-17b23741] {
      display: -webkit-box;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      flex-direction: column;
      -webkit-box-align: start;
      align-items: flex-start;
      margin-bottom: 19px
    }
  </style>
  <script charset="utf-8" src="/_nuxt/a74af29395c72082fb38.js"></script>
  <script charset="utf-8" src="/_nuxt/be10ccc7e0b462932ad0.js"></script>
  <script charset="utf-8" src="/_nuxt/85b8b9a174ead9933c44.js"></script>
  <meta data-n-head="ssr" data-hid="description" name="description" content="Пользовательское соглашение Winbee">
  <style type="text/css">
    .ribbon[data-v-87672964] {
      box-sizing: border-box;
      font-size: 20px;
      font-weight: 700;
      letter-spacing: 1.05px;
      color: #3f2652;
      text-transform: uppercase;
      text-align: center;
      line-height: 50px;
      border-radius: 4px;
      position: relative
    }
    
    .ribbon[data-v-87672964]:after,
    .ribbon[data-v-87672964]:before {
      content: "";
      display: inline-block;
      width: 30px;
      height: 50px;
      position: absolute;
      top: 5px;
      z-index: 0
    }
    
    .ribbon[data-v-87672964]:before {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyOSIgaGVpZ2h0PSI1MCIgdmlld0JveD0iMCAwIDI5IDUwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIuNjU1IDBIMjVhNCA0IDAgMCAxIDQgNHY0MmE0IDQgMCAwIDEtNCA0SDIuNjU1QTIgMiAwIDAgMSAuOTcgNDYuOTIyTDE1IDI1IC45NyAzLjA3OEEyIDIgMCAwIDEgMi42NTUgMHoiLz4KPC9zdmc+Cg==) no-repeat;
      left: -20px
    }
    
    .ribbon[data-v-87672964]:after {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyOSIgaGVpZ2h0PSI1MCIgdmlld0JveD0iMCAwIDI5IDUwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTI2LjM0NSAwSDRhNCA0IDAgMCAwLTQgNHY0MmE0IDQgMCAwIDAgNCA0aDIyLjM0NWEyIDIgMCAwIDAgMS42ODUtMy4wNzhMMTQgMjUgMjguMDMgMy4wNzhBMiAyIDAgMCAwIDI2LjM0NSAweiIvPgo8L3N2Zz4K) no-repeat;
      right: -20px
    }
    
    .ribbon__text[data-v-87672964] {
      position: relative;
      z-index: 1;
      display: block;
      width: 100%;
      height: 100%;
      background-color: #ffed2a;
      border-radius: 4px
    }
    
    @media (max-width:767px) {
      .ribbon[data-v-87672964] {
        margin: 0 auto 29px;
        width: calc(100% - 60px);
        font-size: 14px;
        letter-spacing: .74px;
        line-height: 40px
      }
      .ribbon[data-v-87672964]:after,
      .ribbon[data-v-87672964]:before {
        height: 40px;
        width: 28px
      }
      .ribbon[data-v-87672964]:before {
        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDI2IDQwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIuMDQzIDBIMjJhNCA0IDAgMCAxIDQgNHYzMmE0IDQgMCAwIDEtNCA0SDIuMDQzYTIgMiAwIDAgMS0xLjU5LTMuMjE0TDEzLjI2NyAyMCAuNDUzIDMuMjE0QTIgMiAwIDAgMSAyLjA0MyAweiIvPgo8L3N2Zz4K) no-repeat;
        left: -22px
      }
      .ribbon[data-v-87672964]:after {
        background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDI2IDQwIj4KICAgIDxwYXRoIGZpbGw9IiNGRkNGMDUiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIzLjQwNyAwSDRhNCA0IDAgMCAwLTQgNHYzMmE0IDQgMCAwIDAgNCA0aDE5LjQwN2EyIDIgMCAwIDAgMS43LTMuMDU0TDE0LjYgMjAgMjUuMTA3IDMuMDU0QTIgMiAwIDAgMCAyMy40MDcgMHoiLz4KPC9zdmc+Cg==) no-repeat;
        right: -22px
      }
    }
  </style>
  <style type="text/css">
    .faucet__form[data-v-9354549c] {
      width: 304px;
      margin: auto
    }
    
    @media (max-width:767px) {
      .faucet__form[data-v-9354549c] {
        width: calc(100% - 60px)
      }
    }
    
    .recaptcha[data-v-9354549c] {
      margin-top: 45px;
      margin-bottom: 25px
    }
    
    @media screen and (max-width:320px) {
      .recaptcha__container iframe[data-v-9354549c] {
        transform: scale(.95);
        -webkit-transform: scale(.95);
        -webkit-transform-origin: 0 0;
        transform-origin: 0 0
      }
    }
    
    .balance-info[data-v-9354549c] {
      background-color: hsla(0, 0%, 100%, .1);
      border-radius: 5px;
      font-size: 14px;
      line-height: 1.43;
      text-align: center;
      color: #a698af;
      padding: 10px 30px;
      margin-top: 50px;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    .cell[data-v-7619dbb8] {
      position: relative;
      width: 33.3%;
      height: 33.3%;
      outline: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      -moz-tap-highlight-color: transparent
    }
    
    .round[data-v-7619dbb8] {
      position: absolute;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 80%;
      border-radius: 44.5px;
      box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .17), inset 0 -3px 0 0 #3e2f56;
      background-color: #463958;
      -webkit-transition: box-shadow .1s, background-color .1s, -webkit-transform .1s;
      transition: box-shadow .1s, background-color .1s, -webkit-transform .1s;
      transition: box-shadow .1s, background-color .1s, transform .1s;
      transition: box-shadow .1s, background-color .1s, transform .1s, -webkit-transform .1s;
      will-change: transform
    }
    
    .round.is__loading[data-v-7619dbb8] {
      background: #7f7193 url(/images/mines/loader.svg) 50% no-repeat;
      background-size: 150px;
      box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .47), inset 0 -3px 0 0 #857995
    }
    
    .round-leave-active[data-v-7619dbb8] {
      position: relative;
      z-index: 3;
      -webkit-animation: round-data-v-7619dbb8 .25s ease-out;
      animation: round-data-v-7619dbb8 .25s ease-out
    }
    
    @media(min-width:768px) {
      .cell:not(.is__opened) .round[data-v-7619dbb8]:hover {
        box-shadow: inset 0 0 23px 0 hsla(0, 0%, 100%, .47), inset 0 -3px 0 0 #857995;
        background-color: #7f7193;
        cursor: pointer
      }
    }
    
    .icon[data-v-7619dbb8] {
      position: absolute;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 80%;
      z-index: 2;
      background-repeat: no-repeat;
      background-position: 50%;
      will-change: transform
    }
    
    @media(max-width:767px) {
      .icon[data-v-7619dbb8],
      .round[data-v-7619dbb8] {
        top: 5%;
        left: 5%;
        width: 90%;
        height: 90%
      }
    }
    
    .is__opacity .icon[data-v-7619dbb8] {
      opacity: .3
    }
    
    .icon-enter-active[data-v-7619dbb8] {
      -webkit-animation: object-data-v-7619dbb8 .25s ease-in-out forwards;
      animation: object-data-v-7619dbb8 .25s ease-in-out forwards;
      -webkit-animation-delay: .1s;
      animation-delay: .1s
    }
    
    @-webkit-keyframes round-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
      50% {
        -webkit-transform: scale(1.1);
        transform: scale(1.1)
      }
      to {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
    }
    
    @keyframes round-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
      50% {
        -webkit-transform: scale(1.1);
        transform: scale(1.1)
      }
      to {
        -webkit-transform: scale(0);
        transform: scale(0)
      }
    }
    
    @-webkit-keyframes object-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(.2);
        transform: scale(.2)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
    
    @keyframes object-data-v-7619dbb8 {
      0% {
        -webkit-transform: scale(.2);
        transform: scale(.2)
      }
      to {
        -webkit-transform: scale(1);
        transform: scale(1)
      }
    }
  </style>
  <style type="text/css">
    .field[data-v-8ad8d56a] {
      display: -webkit-box;
      display: flex;
      margin: 0 auto;
      flex-wrap: wrap;
      justify-content: space-around;
      width: 230px;
      height: 230px;
      padding: 10px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-37389b4b] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center;
      width: 100%;
      min-height: 500px;
      background-color: #291a43;
      border-radius: 7px;
      border: 1px solid #000
    }
    
    .content[data-v-37389b4b] {
      margin: 0 auto;
      background-color: #180d2c;
      width: 378px;
      min-height: 320px;
      border-radius: 10px;
      padding: 25px 0;
      border: none
    }
    
    @media (min-width:768px) {
      .ribbon[data-v-37389b4b] {
        width: 414px;
        margin-left: -18px
      }
    }
    
    @media (max-width:767px) {
      .content[data-v-37389b4b] {
        width: calc(100% - 20px)
      }
    }
  </style>
  <style type="text/css">
    .tabs {
      list-style: none;
      color: #a698af;
      font-size: 25px;
      line-height: 81px;
      display: -webkit-box;
      display: flex;
      cursor: pointer
    }
    
    .tabs li {
      margin-right: 35px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-transition: color .5s ease;
      transition: color .5s ease
    }
    
    .tabs li.active {
      color: #fff;
      border-bottom: 4px solid #ffed2a
    }
    
    @media (max-width:767px) {
      .tabs {
        font-size: 20px;
        line-height: 61px;
        padding-left: 10px
      }
      .tabs li {
        margin-right: 25px
      }
    }
  </style>
  <style type="text/css">
    .form__input_icon[data-v-65dd4ae2] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      -webkit-box-align: center;
      align-items: center;
      position: relative
    }
    
    .form__input_icon input[data-v-65dd4ae2] {
      padding-right: 34px
    }
    
    .form__icon[data-v-65dd4ae2] {
      width: 24px;
      height: 24px;
      position: absolute;
      top: 13px;
      right: 10px;
      display: -webkit-box;
      display: flex;
      -webkit-box-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      align-items: center;
      background: #1a1a1a;
      border-radius: 30px;
      color: #7a6e7f;
      font-size: 18px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .form__icon svg[data-v-65dd4ae2] {
      width: 13px;
      fill: #7a6e7f;
      color: #7a6e7f
    }
  </style>
  <style type="text/css">
    .input__container[data-v-a93b1494] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
      align-items: center
    }
    
    .input__input[data-v-a93b1494] {
      width: 100%
    }
    
    @media (max-width:767px) {
      .input__input[data-v-a93b1494] {
        width: calc(100% - 105px)
      }
    }
    
    .input__controls[data-v-a93b1494] {
      margin-left: 10px
    }
    
    .input__controls .row[data-v-a93b1494] {
      display: -webkit-box;
      display: flex
    }
    
    .input__controls .row[data-v-a93b1494]:first-child {
      margin-bottom: 6px
    }
    
    .input__btn[data-v-a93b1494] {
      display: inline-block;
      width: 45px;
      line-height: 22px;
      border-radius: 11px;
      background-color: hsla(0, 0%, 100%, .1);
      border: none;
      font-size: 12px;
      text-align: center;
      color: #a698af;
      cursor: pointer;
      outline: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
    
    .input__btn[data-v-a93b1494]:hover {
      background-color: hsla(0, 0%, 100%, .25);
      color: #fff
    }
    
    .input__btn[data-v-a93b1494]:active {
      background-color: #ffed2a;
      color: #3f2652
    }
    
    .input__btn[data-v-a93b1494]:first-child {
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    .deposit-form[data-v-5916d354] {
      display: -webkit-box;
      display: flex;
      margin: 0 auto;
      width: 600px;
      border-radius: 7px;
      box-shadow: 0 15px 35px 0 rgba(0, 0, 0, .2549);
      background-color: hsla(0, 0%, 100%, .09804)
    }
    
    .deposit-form__form[data-v-5916d354] {
      width: 340px;
      padding: 25px 35px 35px
    }
    
    .deposit-form__fee[data-v-5916d354] {
      margin-top: 10px;
      padding: 6px;
      font-size: 12px;
      border-radius: 7px;
      background-color: #33254c;
      text-align: center;
      color: #a698af
    }
    
    .deposit-form__fee span[data-v-5916d354] {
      color: #ffed2a
    }
    
    .deposit-form__info[data-v-5916d354] {
      width: 260px;
      padding: 0 25px;
      border-radius: 0 7px 7px 0;
      background-color: #33254c;
      color: #a698af;
      font-size: 14px
    }
    
    .deposit-form__info ul[data-v-5916d354] {
      margin-top: 25px;
      list-style: none
    }
    
    .deposit-form__info li[data-v-5916d354] {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiM4NTc3OTMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNjI4YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY4LjM5NmMtLjggMS4wMTItMS45MjMgMS4yNS0yLjkwMS45NThBMi45NDMgMi45NDMgMCAwIDEgLjAwOSA2LjI5Qy4yNDcgMy4wNTQgNSAzIDUuNS4yMjIgNiAzIDEwLjgxNSAzLjExNCAxMC45OTUgNi4yOTJjLjE1NiAyLjc4My0zLjEwNCA0LjM4Mi00Ljk5MSAyLjA0OXoiLz4KPC9zdmc+Cg==) no-repeat 0;
      padding-left: 20px;
      line-height: 1.29;
      margin-bottom: 20px
    }
    
    .deposit-form__confirm[data-v-5916d354] {
      margin: 25px;
      padding-top: 60px;
      padding-bottom: 60px;
      border-radius: 7px;
      background-color: #1b0d33;
      text-align: center
    }
    
    .deposit-form__confirm p[data-v-5916d354] {
      font-size: 20px;
      text-align: center;
      color: #fff;
      margin-bottom: 25px
    }
    
    .deposit-form__confirm button[data-v-5916d354] {
      width: 200px
    }
    
    .deposit-form__payment-form[data-v-5916d354] {
      display: none
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .deposit-form[data-v-5916d354] {
        width: 100%;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        padding: 20px 10px;
        border-radius: 0
      }
      .deposit-form__form[data-v-5916d354] {
        width: 100%;
        padding: 0;
        margin-bottom: 20px
      }
      .deposit-form__info[data-v-5916d354] {
        width: 100%;
        border-radius: 7px
      }
    }
  </style>
  <style type="text/css">
    .deposit-history[data-v-6a6b5a56] {
      width: 100%;
      background-color: hsla(0, 0%, 100%, .09804);
      border-collapse: collapse;
      color: #9c8ea6;
      border-radius: 7px;
      font-size: 14px;
      text-align: left;
      overflow: hidden
    }
    
    .deposit-history thead[data-v-6a6b5a56] {
      background-color: #201435;
      color: #a698af;
      text-transform: uppercase;
      font-size: 12px
    }
    
    .deposit-history tr[data-v-6a6b5a56] {
      background: #24173c;
      border-bottom: hsla(0, 0%, 100%, .09804)
    }
    
    .deposit-history td[data-v-6a6b5a56],
    .deposit-history th[data-v-6a6b5a56] {
      height: 50px;
      padding-left: 20px
    }
    
    .deposit-history img[data-v-6a6b5a56] {
      vertical-align: middle;
      height: 18px
    }
    
    .deposit-history .status__process[data-v-6a6b5a56] {
      color: #fff
    }
    
    .deposit-history .status__process[data-v-6a6b5a56]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgdmlld0JveD0iMCAwIDEzIDEzIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuNSAwYTYuNSA2LjUgMCAxIDEgMCAxMyA2LjUgNi41IDAgMCAxIDAtMTN6bTAgMS4zYTUuMiA1LjIgMCAxIDAgMCAxMC40IDUuMiA1LjIgMCAwIDAgMC0xMC40ek03IDN2M2gydjFINlYzaDF6Ii8+Cjwvc3ZnPgo=);
      margin-right: 5px
    }
    
    .deposit-history .status__manual[data-v-6a6b5a56] {
      color: #fff
    }
    
    .deposit-history .status__manual[data-v-6a6b5a56]:before {
      content: url(/_nuxt/img/d4360e4.svg);
      margin-right: 5px;
      position: relative;
      top: 4px
    }
    
    .deposit-history .status__success[data-v-6a6b5a56] {
      color: #91ff4a
    }
    
    .deposit-history .status__success[data-v-6a6b5a56]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMSIgdmlld0JveD0iMCAwIDEyIDExIj4KICAgIDxwYXRoIGZpbGw9IiM4MURENDciIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEuNzA3IDUuMjkzQTEgMSAwIDAgMCAuMjkzIDYuNzA3bDQgNGExIDEgMCAwIDAgMS41MzktLjE1Mmw2LTlhMSAxIDAgMSAwLTEuNjY0LTEuMTFMNC44NDUgOC40MyAxLjcwNyA1LjI5M3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
    
    .deposit-history .status__fail[data-v-6a6b5a56] {
      color: #ff6764
    }
    
    .deposit-history .status__fail[data-v-6a6b5a56]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNGRjY3NjQiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAwTDYgNC41ODYgOS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAxLjQxNEw3LjQxNCA2bDMuNzkzIDMuNzkzYTEgMSAwIDAgMSAuMDgzIDEuMzJsLS4wODMuMDk0YTEgMSAwIDAgMS0xLjQxNCAwTDYgNy40MTRsLTMuNzkzIDMuNzkzQTEgMSAwIDAgMSAuNzkzIDkuNzkzTDQuNTg2IDYgLjc5MyAyLjIwN0ExIDEgMCAwIDEgLjcxLjg4N3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .deposit-history td[data-v-6a6b5a56],
      .deposit-history th[data-v-6a6b5a56] {
        padding-left: 10px
      }
      .deposit-history td[data-v-6a6b5a56]:nth-child(4),
      .deposit-history td span[data-v-6a6b5a56],
      .deposit-history th[data-v-6a6b5a56]:nth-child(4) {
        display: none
      }
    }
  </style>
  <style type="text/css">
    .payment-system[data-v-6fbadca7] {
      margin: 0 0 20px 20px;
      padding: 20px 15px 10px;
      width: 135px;
      height: 120px;
      border-radius: 7px;
      border: 1px solid hsla(0, 0%, 100%, .2);
      cursor: pointer;
      text-align: center
    }
    
    .payment-system_active[data-v-6fbadca7] {
      border: 2px solid #ffed2a
    }
    
    .payment-system__description[data-v-6fbadca7] {
      margin-top: 12px;
      display: -webkit-box;
      display: flex;
      -webkit-box-align: baseline;
      align-items: baseline;
      -webkit-box-pack: justify;
      justify-content: space-between
    }
    
    .payment-system__name[data-v-6fbadca7] {
      font-size: 16px;
      color: #fff
    }
    
    .payment-system_active .payment-system__name[data-v-6fbadca7] {
      color: #ffed2a
    }
    
    .payment-system__percent[data-v-6fbadca7] {
      font-size: 12px;
      color: #a698af
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .payment-system[data-v-6fbadca7] {
        margin: 0 0 10px 10px;
        padding: 11px;
        width: 110px;
        height: 95px
      }
      .payment-system__image[data-v-6fbadca7] {
        width: 50px;
        margin-top: 2px
      }
      .payment-system__name[data-v-6fbadca7] {
        font-size: 12px
      }
    }
  </style>
  <style type="text/css">
    .wrapper__50px[data-v-dc402bf2] {
      padding: 0 50px
    }
    
    .wrapper__50px p[data-v-dc402bf2] {
      margin-bottom: 10px
    }
    
    .wrapper__50px button[data-v-dc402bf2] {
      width: 100%
    }
    
    .wrapper__50px .content[data-v-dc402bf2] {
      color: #fff;
      font-size: 16px;
      line-height: 24px
    }
    
    .wrapper__50px h4[data-v-dc402bf2] {
      font-size: 20px;
      color: #fff;
      margin-bottom: 15px
    }
    
    .wrapper__50px h5[data-v-dc402bf2] {
      font-size: 16px;
      color: #fff;
      margin-bottom: 10px
    }
    
    .wrapper__50px ul li[data-v-dc402bf2] {
      color: #a698af;
      font-size: 12px;
      line-height: 18px;
      margin-bottom: 6px;
      list-style-type: none
    }
    
    .wrapper__50px ul li[data-v-dc402bf2]:before {
      content: "\2022 ";
      color: #ffed2a;
      padding-right: .5em
    }
    
    @media screen and (max-width:719px) {
      .wrapper__50px[data-v-dc402bf2] {
        padding: 0 15px
      }
    }
  </style>
  <style type="text/css">
    .deposit-tab__form[data-v-1c225c0e] {
      width: 816px;
      margin: 0 auto;
      padding: 35px 0
    }
    
    .deposit-wallets[data-v-1c225c0e] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 9px;
      padding: 0 90px
    }
    
    .deposit-tab h3[data-v-1c225c0e] {
      text-align: center;
      margin-bottom: 25px
    }
    
    .deposit-tab__history[data-v-1c225c0e] {
      padding: 0 130px;
      margin-bottom: 35px
    }
    
    .deposit-tab__history__button[data-v-1c225c0e] {
      width: 160px;
      margin: 20px auto
    }
    
    .deposit-tab__history-empty[data-v-1c225c0e] {
      text-align: center;
      color: #fff;
      width: 100%;
      font-size: 16px;
      margin-bottom: 25px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .deposit-tab__form[data-v-1c225c0e] {
        width: 100%;
        padding: 20px 0
      }
      .deposit-tab__history[data-v-1c225c0e],
      .deposit-wallets[data-v-1c225c0e] {
        padding: 0
      }
    }
  </style>
  <style type="text/css">
    .withdraw-form[data-v-ca12132a] {
      display: -webkit-box;
      display: flex;
      margin: 0 auto;
      width: 600px;
      border-radius: 7px;
      box-shadow: 0 15px 35px 0 rgba(0, 0, 0, .2549);
      background-color: hsla(0, 0%, 100%, .09804)
    }
    
    .withdraw-form__confirm[data-v-ca12132a],
    .withdraw-form__form[data-v-ca12132a] {
      width: 340px;
      padding: 25px 35px 35px
    }
    
    .withdraw-form__amount[data-v-ca12132a] {
      display: -webkit-box;
      display: flex
    }
    
    .withdraw-form__amount__input[data-v-ca12132a] {
      width: 50%
    }
    
    .withdraw-form__amount__fee[data-v-ca12132a] {
      width: 50%;
      margin-left: 15px;
      border-radius: 4px;
      background-color: #33254c;
      font-size: 12px;
      color: #a698af;
      line-height: normal;
      padding: 9px 14px
    }
    
    .withdraw-form__amount__fee span[data-v-ca12132a] {
      color: #ffed2a
    }
    
    .withdraw-form__confirm[data-v-ca12132a] {
      color: #fff;
      text-align: center
    }
    
    .withdraw-form__confirm p[data-v-ca12132a] {
      padding-top: 10;
      font-size: 16px;
      line-height: 1.3
    }
    
    .withdraw-form__confirm span[data-v-ca12132a] {
      display: block;
      width: 100%;
      text-align: center;
      font-size: 30px;
      margin-top: 30px;
      margin-bottom: 30px
    }
    
    .withdraw-form__confirm__buttons[data-v-ca12132a] {
      display: inline-block;
      width: 160px
    }
    
    .withdraw-form__confirm__buttons button[data-v-ca12132a]:first-child {
      margin-bottom: 15px
    }
    
    .withdraw-form__info[data-v-ca12132a] {
      width: 260px;
      padding: 0 25px;
      border-radius: 0 7px 7px 0;
      background-color: #33254c;
      color: #a698af;
      font-size: 14px
    }
    
    .withdraw-form__info ul[data-v-ca12132a] {
      margin-top: 25px;
      list-style: none
    }
    
    .withdraw-form__info li[data-v-ca12132a] {
      background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMSIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDExIDEyIj4KICAgIDxwYXRoIGZpbGw9IiM4NTc3OTMiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuMDA0IDguNjI4YzAgLjc1MiAwIDEuNTQzLS4wMDQgMi4zNzJoMWwxIDFIM2wxLTFoMVY4LjM5NmMtLjggMS4wMTItMS45MjMgMS4yNS0yLjkwMS45NThBMi45NDMgMi45NDMgMCAwIDEgLjAwOSA2LjI5Qy4yNDcgMy4wNTQgNSAzIDUuNS4yMjIgNiAzIDEwLjgxNSAzLjExNCAxMC45OTUgNi4yOTJjLjE1NiAyLjc4My0zLjEwNCA0LjM4Mi00Ljk5MSAyLjA0OXoiLz4KPC9zdmc+Cg==) no-repeat 0;
      padding-left: 20px;
      line-height: 1.29;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .withdraw-form[data-v-ca12132a] {
        width: 100%;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        padding: 20px 10px;
        border-radius: 0
      }
      .withdraw-form__confirm[data-v-ca12132a],
      .withdraw-form__form[data-v-ca12132a] {
        width: 100%;
        padding: 0;
        margin-bottom: 20px
      }
      .withdraw-form__confirm[data-v-ca12132a] {
        border-radius: 7px;
        padding: 20px
      }
      .withdraw-form__info[data-v-ca12132a] {
        width: 100%;
        border-radius: 7px
      }
    }
  </style>
  <style type="text/css">
    .withdraw-history[data-v-d566925e] {
      width: 100%;
      background-color: hsla(0, 0%, 100%, .09804);
      border-collapse: collapse;
      color: #9c8ea6;
      border-radius: 7px;
      font-size: 14px;
      text-align: left;
      overflow: hidden
    }
    
    .withdraw-history thead[data-v-d566925e] {
      background-color: #201435;
      color: #a698af;
      text-transform: uppercase;
      font-size: 12px
    }
    
    .withdraw-history tr[data-v-d566925e] {
      background: #24173c;
      border-bottom: hsla(0, 0%, 100%, .09804)
    }
    
    .withdraw-history td[data-v-d566925e],
    .withdraw-history th[data-v-d566925e] {
      height: 50px;
      padding-left: 20px
    }
    
    .withdraw-history img[data-v-d566925e] {
      vertical-align: middle;
      height: 18px
    }
    
    .withdraw-history .status__process[data-v-d566925e] {
      color: #fff
    }
    
    .withdraw-history .status__process[data-v-d566925e]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgdmlld0JveD0iMCAwIDEzIDEzIj4KICAgIDxwYXRoIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTYuNSAwYTYuNSA2LjUgMCAxIDEgMCAxMyA2LjUgNi41IDAgMCAxIDAtMTN6bTAgMS4zYTUuMiA1LjIgMCAxIDAgMCAxMC40IDUuMiA1LjIgMCAwIDAgMC0xMC40ek03IDN2M2gydjFINlYzaDF6Ii8+Cjwvc3ZnPgo=);
      margin-right: 5px
    }
    
    .withdraw-history .status__manual[data-v-d566925e] {
      color: #fff
    }
    
    .withdraw-history .status__manual[data-v-d566925e]:before {
      content: url(/_nuxt/img/d4360e4.svg);
      margin-right: 5px;
      position: relative;
      top: 4px
    }
    
    .withdraw-history .status__success[data-v-d566925e] {
      color: #91ff4a
    }
    
    .withdraw-history .status__success[data-v-d566925e]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMSIgdmlld0JveD0iMCAwIDEyIDExIj4KICAgIDxwYXRoIGZpbGw9IiM4MURENDciIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTTEuNzA3IDUuMjkzQTEgMSAwIDAgMCAuMjkzIDYuNzA3bDQgNGExIDEgMCAwIDAgMS41MzktLjE1Mmw2LTlhMSAxIDAgMSAwLTEuNjY0LTEuMTFMNC44NDUgOC40MyAxLjcwNyA1LjI5M3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
    
    .withdraw-history .status__fail[data-v-d566925e] {
      color: #ff6764
    }
    
    .withdraw-history .status__fail[data-v-d566925e]:before {
      content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj4KICAgIDxwYXRoIGZpbGw9IiNGRjY3NjQiIGZpbGwtcnVsZT0ibm9uemVybyIgZD0iTS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAwTDYgNC41ODYgOS43OTMuNzkzYTEgMSAwIDAgMSAxLjQxNCAxLjQxNEw3LjQxNCA2bDMuNzkzIDMuNzkzYTEgMSAwIDAgMSAuMDgzIDEuMzJsLS4wODMuMDk0YTEgMSAwIDAgMS0xLjQxNCAwTDYgNy40MTRsLTMuNzkzIDMuNzkzQTEgMSAwIDAgMSAuNzkzIDkuNzkzTDQuNTg2IDYgLjc5MyAyLjIwN0ExIDEgMCAwIDEgLjcxLjg4N3oiLz4KPC9zdmc+Cg==);
      margin-right: 5px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .withdraw-history td[data-v-d566925e],
      .withdraw-history th[data-v-d566925e] {
        padding-left: 10px;
        font-size: 12px
      }
      .withdraw-history td[data-v-d566925e]:nth-child(4),
      .withdraw-history td span[data-v-d566925e],
      .withdraw-history th[data-v-d566925e]:nth-child(4) {
        display: none
      }
    }
  </style>
  <style type="text/css">
    .content[data-v-4a019f7e] {
      margin: 35px 0 0;
      padding: 20px
    }
    
    .content[data-v-4a019f7e],
    p[data-v-4a019f7e] {
      text-align: center
    }
    
    p[data-v-4a019f7e] {
      font-size: 16px;
      line-height: 24px;
      margin-top: 5px;
      margin-bottom: 30px
    }
    
    h3[data-v-4a019f7e],
    p[data-v-4a019f7e] {
      color: #fff
    }
    
    h3[data-v-4a019f7e] {
      margin-top: 15px;
      font-size: 20px;
      line-height: 28px
    }
    
    .content img[data-v-4a019f7e] {
      width: 120px;
      height: 120px
    }
    
    .content button[data-v-4a019f7e] {
      max-width: 200px
    }
  </style>
  <style type="text/css">
    .withdaw-tab__form[data-v-04507943] {
      width: 816px;
      margin: 0 auto;
      padding: 35px 0
    }
    
    .withdraw-wallets[data-v-04507943] {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap;
      margin-bottom: 9px;
      padding: 0 90px
    }
    
    .withdraw-tab h3[data-v-04507943] {
      text-align: center;
      margin-bottom: 25px
    }
    
    .withdraw-tab__history[data-v-04507943] {
      padding: 0 130px;
      margin-bottom: 35px
    }
    
    .withdraw-tab__history__button[data-v-04507943] {
      width: 160px;
      margin: 20px auto
    }
    
    .withdraw-tab__history-empty[data-v-04507943] {
      text-align: center;
      color: #fff;
      width: 100%;
      font-size: 16px;
      margin-bottom: 25px
    }
  </style>
  <style type="text/css">
    @media screen and (max-width:1199px) {
      .withdaw-tab__form[data-v-04507943] {
        width: 100%;
        padding: 20px 0
      }
      .withdraw-tab__history[data-v-04507943],
      .withdraw-wallets[data-v-04507943] {
        padding: 0
      }
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-d5688f28] {
      width: 100%;
      min-height: 500px;
      background-color: #291a43;
      border-radius: 7px;
      border: 1px solid #000
    }
    
    .header[data-v-d5688f28] {
      width: 100%;
      height: 85px;
      border-bottom: 1px solid #3f3256
    }
    
    .header__content[data-v-d5688f28] {
      width: 600px;
      margin: 0 auto
    }
    
    @media (max-width:767px) {
      .header__content[data-v-d5688f28] {
        width: calc(100% - 20px)
      }
      .header[data-v-d5688f28] {
        height: 65px
      }
    }
  </style>
  <style type="text/css">
    .panel[data-v-5e717cea] {
      width: 100%;
      background-color: #3e3156;
      border-radius: 7px;
      padding: 20px 30px;
      margin-bottom: 20px
    }
  </style>
  <style type="text/css">
    .profile[data-v-19952362] {
      width: 600px;
      margin: 0 auto;
      padding-bottom: 30px;
      padding-top: 30px
    }
    
    .ribbon[data-v-19952362] {
      margin-left: 0;
      margin-bottom: 35px
    }
    
    .form__row[data-v-19952362] {
      margin-top: 20px;
      display: -webkit-box;
      display: flex
    }
    
    .form__row_input[data-v-19952362] {
      width: 60%
    }
    
    .form__row_hint[data-v-19952362] {
      width: 37%;
      margin-left: 3%;
      border-radius: 7px;
      background-color: #504269;
      font-size: 12px;
      line-height: 1.33;
      color: #a698af;
      padding: 8px 12px
    }
    
    .profile button[data-v-19952362] {
      max-width: 200px
    }
    
    .footer[data-v-19952362] {
      border-top: 1px solid #3f3256
    }
    
    .logout[data-v-19952362] {
      cursor: pointer;
      color: #ffed2a;
      font-size: 14px;
      text-align: center;
      line-height: 50px
    }
    
    @media (max-width:767px) {
      .profile[data-v-19952362] {
        width: calc(100% - 20px);
        padding-bottom: 25px
      }
      .ribbon[data-v-19952362] {
        width: calc(100% - 40px);
        margin: 0 auto 25px
      }
      .form__row[data-v-19952362] {
        display: block
      }
      .form__row_hint[data-v-19952362],
      .form__row_input[data-v-19952362] {
        width: 100%;
        margin-left: 0
      }
      .form__row_hint[data-v-19952362] {
        margin-top: 10px
      }
      .profile button[data-v-19952362] {
        max-width: 100%
      }
    }
  </style>
  <style type="text/css">
    .form__input[data-v-7cf5a121] {
      position: relative
    }
    
    button[data-v-7cf5a121] {
      cursor: pointer;
      width: 18px;
      height: 18px;
      position: absolute;
      top: 16px;
      right: 30px;
      background: transparent;
      border: none;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none
    }
  </style>
  <style type="text/css">
    .partner_rules__wrapper[data-v-76346bb4] {
      padding: 0 25px
    }
    
    .partner_rules__wrapper h4[data-v-76346bb4] {
      margin-bottom: 10px
    }
    
    .partner_rules__wrapper h4.deny[data-v-76346bb4] {
      margin-top: 20px
    }
    
    p[data-v-76346bb4] {
      font-size: 14px;
      line-height: 21px;
      margin-bottom: 10px
    }
    
    p[data-v-76346bb4],
    ul[data-v-76346bb4] {
      color: #fff
    }
    
    ul[data-v-76346bb4] {
      margin-bottom: 20px;
      margin-left: 10px;
      line-height: 2
    }
    
    .partner_rules__wrapper .panel[data-v-76346bb4] {
      color: #a698af;
      font-size: 18px;
      line-height: 25px
    }
    
    .action[data-v-76346bb4] {
      max-width: 150px;
      margin: 20px auto 0
    }
  </style>
  <style type="text/css">
    .partner__wrapper[data-v-0f06326d] {
      position: relative
    }
    
    .partner__cover[data-v-0f06326d] {
      width: 100%;
      height: 464px;
      position: absolute;
      left: 0;
      top: 0;
      background: #000;
      opacity: .3;
      border-bottom-left-radius: 99px;
      border-bottom-right-radius: 99px
    }
    
    .partner__content[data-v-0f06326d] {
      position: relative;
      min-height: 600px;
      margin: 0 auto;
      text-align: center;
      z-index: 1
    }
    
    .partner__content button[data-v-0f06326d] {
      margin: 25px auto 35px;
      text-transform: uppercase;
      max-width: 250px
    }
    
    .partner__content h3[data-v-0f06326d] {
      margin-bottom: 30px
    }
    
    .partner__image[data-v-0f06326d] {
      margin-top: 60px
    }
    
    .partner__header[data-v-0f06326d] {
      margin: 25px auto 0;
      max-width: 600px
    }
    
    .partner__header .yellow[data-v-0f06326d] {
      color: #ffed2a
    }
    
    .partner__panels[data-v-0f06326d] {
      display: -webkit-box;
      display: flex;
      text-align: left;
      padding: 0 100px
    }
    
    .partner__panels h4[data-v-0f06326d] {
      margin-bottom: 20px
    }
    
    .partner__panels span[data-v-0f06326d] {
      font-size: 14px;
      line-height: 1.43;
      color: #a698af
    }
    
    .partner__panels .description[data-v-0f06326d] {
      display: inline-block;
      margin-top: 13px
    }
    
    .partner__counters[data-v-0f06326d] {
      width: 50%;
      margin-left: 15px
    }
    
    .partner__counters .panel[data-v-0f06326d] {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: end;
      align-items: flex-end;
      padding: 15px 20px
    }
    
    .counter__icon[data-v-0f06326d] {
      margin-right: 13px
    }
    
    .counter__value[data-v-0f06326d] {
      color: #fff;
      font-size: 27px
    }
    
    .counter__value span[data-v-0f06326d] {
      display: block
    }
    
    .partner__table[data-v-0f06326d] {
      padding: 0 100px;
      margin: 0 auto 35px
    }
    
    @media screen and (max-width:767px) {
      .partner__header[data-v-0f06326d] {
        font-size: 20px
      }
      .partner__panels[data-v-0f06326d] {
        display: block;
        padding: 0
      }
      .panel[data-v-0f06326d] {
        padding: 15px 10px
      }
      .partner__counters[data-v-0f06326d] {
        display: -webkit-box;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        flex-direction: column;
        width: auto;
        margin-left: 0
      }
      .partner__table[data-v-0f06326d] {
        padding: 0
      }
    }
  </style>
  <style type="text/css">
    .partner__table {
      text-align: left
    }
    
    .partner__table .th:nth-child(2),
    .partner__table td:nth-child(2) {
      width: 175px
    }
    
    @media screen and (max-width:767px) {
      .partner__table .th:nth-child(2),
      .partner__table .th:nth-child(5),
      .partner__table td:nth-child(2),
      .partner__table td:nth-child(5) {
        display: none!important
      }
    }
  </style>
  <style type="text/css">
    .wrapper[data-v-f08d7dc8] {
      width: 100%;
      min-height: 500px;
      background-color: #291a43;
      border-radius: 7px;
      border: 1px solid #000
    }
    
    .header[data-v-f08d7dc8] {
      width: 100%;
      height: 85px;
      border-bottom: 1px solid #3f3256
    }
    
    .header__content[data-v-f08d7dc8] {
      width: 600px;
      margin: 0 auto
    }
    
    @media (max-width:767px) {
      .header__content[data-v-f08d7dc8] {
        width: calc(100% - 20px)
      }
      .header[data-v-f08d7dc8] {
        height: 65px
      }
    }
  </style>
</head>

<body>
  <div id="__nuxt">
    <!---->
    <div id="__layout">
      <div data-v-31cda96b="">
        <header class="header" data-v-180c07fb="" data-v-31cda96b="">
          <a href="/" class="logo nuxt-link-active" data-v-2b804d1f="" data-v-180c07fb=""><? echo $site_name;?></a>
          <ul class="menu-desktop" data-v-52012dc4="" data-v-180c07fb="">
            <li class="menu__item" data-v-52012dc4=""><a href="/" class="menu__link" data-v-52012dc4="">
      Игры
    </a>
              <!---->
            </li>
            <li class="menu__item" data-v-52012dc4=""><a href="/faucet" class="menu__link" data-v-52012dc4="">
      Кран
    </a>
              <!---->
            </li>
            <li class="menu__item" data-v-52012dc4="">
              <!----><a href="promo" class="menu__link" data-v-52012dc4="">
      Промокод
    </a></li>
          </ul>
          <div class="menu-mobile" data-v-58233ac6="" data-v-180c07fb="">
            <ul class="menu__items" data-v-58233ac6="">
              <li class="menu__item" data-v-58233ac6="">
                <a href="/" class="menu__link" data-v-58233ac6="">
                  <div class="menu__icon" data-v-58233ac6=""><img src="/images/menu/games.svg" class="menu__icon_default" data-v-58233ac6=""> <img src="/images/menu/games_active.svg" class="menu__icon_active" data-v-58233ac6=""></div>
                  Игры
                </a>
                <!---->
              </li>
              <li class="menu__item" data-v-58233ac6="">
                <a href="/faucet" class="menu__link" data-v-58233ac6="">
                  <div class="menu__icon" data-v-58233ac6=""><img src="/images/menu/faucet.svg" class="menu__icon_default" data-v-58233ac6=""> <img src="/images/menu/faucet_active.svg" class="menu__icon_active" data-v-58233ac6=""></div>
                  Кран
                </a>
                <!---->
              </li>
              <li class="menu__item" data-v-58233ac6="">
                <!----><span class="menu__link" data-v-58233ac6=""><div class="menu__icon" data-v-58233ac6=""><img src="/images/menu/giftcode.svg" class="menu__icon_default" data-v-58233ac6=""> <img src="/images/menu/giftcode_active.svg" class="menu__icon_active" data-v-58233ac6=""></div>
        Промокод
      </span></li>
            </ul>
            <div class="menu__additional" data-v-58233ac6="">
              <div class="chat-button" data-v-75f76985="" data-v-58233ac6=""></div>
            </div>
          </div>
          <!---->
          <div class="header__user" data-v-180c07fb="">
            <div class="balance" data-v-1d7aa3c2="" data-v-180c07fb=""><span data-v-1d7aa3c2=""><?echo $money;?></span> ₽
            </div> <a href="/wallet" class="wallet" data-v-2f84b7f5="" data-v-180c07fb="">
  Кошелек
</a>
            <a href="/profile" class="profile" data-v-2be93831="" data-v-180c07fb=""></a>
          </div>
        </header>
        <div class="content" data-v-31cda96b="">
          <div class="content__wrap" data-v-31cda96b="">
            <div data-v-1aec7022="" data-v-31cda96b="" class="content__container">
              <section data-v-1aec7022="" class="terms content__terms">
                <div data-v-1aec7022="" class="content__header">
                  <h1 data-v-1aec7022="">Пользовательское соглашение</h1></div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__text">
                      ВНИМАНИЕ! Если Вы не согласны с условиями настоящего Пользовательского Соглашения, не авторизуйтесь на Сайте <?echo  $_SERVER['HTTP_HOST'];?> и не используйте сервисы данного Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    1.ТЕРМИНЫ И ОПРЕДЕЛЕНИЯ.
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В настоящем Соглашении, если из текста прямо не вытекает иное, следующие термины будут иметь указанные ниже значения:
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Сайт - совокупность информации, текстов, графических элементов, дизайна, изображений, фото и видеоматериалов и иных результатов интеллектуальной деятельности, а также программ для ЭВМ, содержащихся в информационной системе, обеспечивающей доступность такой информации в сети Интернет по сетевому адресу <?echo  $_SERVER['HTTP_HOST'];?>. Сайт является Интернет-ресурсом, предназначенным для оказания развлекательно-аттракционных услуг физическим лицам.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Соглашение – настоящее Пользовательское Соглашение, являющееся Публичной офертой, в целом без изъятий и оговорок.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор – лицо, в коммерческом управлении которого находится Сайт.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователь – лицо, заключившее с Администратором Соглашение, путем акцепта настоящей оферты, расположенной в сети Интернет по сетевому адресу <?echo  $_SERVER['HTTP_HOST'];?>/terms. Сотрудники Администратора и родственники таких сотрудников не вправе акцептовать настоящую оферту и заключать Соглашение.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.5
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Стороны – Администратор и Пользователь, являющиеся Сторонами настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.6
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Услуга – действия Администратора по организации работы Сайта и предоставлению Пользователю на безвозмездной и возмездной основе возможности проведения досуга в виде участия в безрисковых играх и развлечениях с использованием сервисов Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.7
                    </div>
                    <div data-v-1aec7022="" class="terms__text"><span data-v-1aec7022="" class="b-rub">Р</span> – виртуальная игровая единица Сайта, используемая в процессе оказания Администратором /получения Пользователем Услуги Сайта. Виртуальные игровые единицы – <span data-v-1aec7022="" class="b-rub">Р</span> Сайта <?echo  $_SERVER['HTTP_HOST'];?> – используются только в рамках Сайта и не могут быть предметом каких бы то ни было сделок и операций вне Сайта. Приобретение Пользователем виртуальных игровых единиц – <span data-v-1aec7022="" class="b-rub">Р</span> – осуществляется только на Сайте и по правилам, указанным в настоящем Соглашении.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.8
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Ставка - электронный документ, формируемый с помощью сервисов Сайта по указанию Пользователя, совершенным им на Сайте по средством специальных программных команд. Указанный электронный документ – Ставка – служит целям оформления/фиксации участия Пользователя, совершившего конкретную Ставку, в том или ином Раунде развлекательных безрисковых игр на Сайте. Ставки формируются с использованием (списанием) <span data-v-1aec7022="" class="b-rub">Р</span>.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.1.9
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Раунд – временной отрезок/часть безрисковых игр, составляющих Услуги Сайта. Каждый раунд имеет момент начала и момент завершения. В ходе каждого раунда Пользователи могут совершать Ставки и узнавать результат безрисковой игры в текущем Раунде.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Все остальные термины и определения, встречающиеся в тексте настоящего Соглашения, толкуются Сторонами в контексте значения терминов, указанных в п. 1.1. настоящего Соглашения, и в соответствии со сложившимися в сети Интернет обычными правилами толкования соответствующих терминов, не противоречащим положениям настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Названия заголовков (статей) настоящего Соглашения предназначены исключительно для удобства пользования текстом Соглашения и буквального юридического значения не имеют.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      1.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В случае разночтений/несовпадений в трактовке терминов и определений в тексте настоящего Соглашения и в тексте правил и норм, размещенных на Сайте (например, в разделе «Помощь» Сайта) применяется и считается приоритетным толкование, содержащееся в тексте настоящего Соглашения (Публичной оферты).
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    2. ПРЕДМЕТ СОГЛАШЕНИЯ.
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      2.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Предметом настоящего Соглашения является предложение Администратора, обращенное к потенциальному Пользователю, получать с использованием сервисов Сайта развлекательно-аттракционные Услуги строго на условиях настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      2.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Лицо, акцептовавшее настоящую оферту, становится Пользователем и обязуется использовать Сайт только на условиях настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      2.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользование Услугами Сайта лицами, не обладающими полной дееспособностью (как по возрасту, так и по состоянию здоровья) в соответствии с нормами и законами соответствующей юрисдикции (страны пребывания физического лица) ЗАПРЕЩЕНО.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    3. ЗАКЛЮЧЕНИЕ, ИЗМЕНЕНИЕ, РАСТОРЖЕНИЕ СОГЛАШЕНИЯ
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор предоставляет Пользователю доступ к информации о Сайте, информации об Услугах Сайта, тексту настоящего Соглашения и иных нормативных документов, устанавливающих правила и нормы получения Услуг Сайта, до авторизации Пользователя на Сайте. После авторизации на Сайте Пользователю предоставляется возможность получения Услуг Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Настоящее Соглашения считается заключенным с момента авторизации Пользователя на Сайте через введение в специальной форме логина и пароля учетной записи.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.2.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Авторизуясь на Сайте, Пользователь выражает свое прямое, полное, безоговорочное и безусловное согласие с нормами настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор в одностороннем порядке вправе в любой момент изменить, отменить, дополнить любые условия настоящего Соглашения и иных нормативных документов Сайта (правил, размещенных на Сайте и содержащих указания на нормы и порядок оказания Услуг сайта) без предварительного согласования с Пользователем.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.3.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Измененный/дополненный текст настоящего Соглашения становится обязательным для всех без исключения авторизованных Пользователей по истечение 12 (двенадцати) часов с момента размещения измененного/дополненного текста Соглашения по сетевому адресу: <?echo  $_SERVER['HTTP_HOST'];?>/terms.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.3.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователь обязан самостоятельно следить за изменениями в тексте Соглашения, размещенного по сетевому адресу: <?echo  $_SERVER['HTTP_HOST'];?>/terms. Если по одностороннему усмотрению Администратора изменения потребуют персонального дополнительного уведомления Пользователей, то Администратор вправе (но не обязан) персонально уведомить круг Пользователей, которых могут коснуться изменения/дополнения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.3.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Использование Пользователем Сайта и его Услуг и сервисов после размещения по сетевому адресу: <?echo  $_SERVER['HTTP_HOST'];?>/terms измененного текста настоящего Пользовательского Соглашения означает полное и безоговорочное согласие Пользователя с всеми без исключения нормами измененного текста Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      При достижении 12ти месячного периода (подряд) отсутствия авторизации на Сайте от имени Администратора Пользователю направляется электронное уведомление о расторжении Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.4.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Если в течение 30 (тридцати) календарных дней с момента направления уведомления, Пользователь не совершил авторизацию на Сайте и не возобновил пользование Услугами Сайта, настоящее Соглашение с конкретным Пользователем считается расторгнутым.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      3.4.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В случае расторжения настоящего Соглашения весь остаток виртуальных игровых единиц – <span data-v-1aec7022="" class="b-rub">Р</span>, имевшихся у Пользователя при пользовании Услугами на Сайте – аннулируется в момент расторжения Соглашения без какой бы то ни было компенсации (оплаченных и не потребленных развлекательных Услуг) в сторону Пользователя. После расторжения настоящего Соглашения Пользователь не вправе заявлять какие бы то ни было требования в адрес Администратора и Сайта, в том числе, но, не ограничиваясь: не вправе требовать возврата денежных средств за оплаченную, но не потребленную Услугу и т.п.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    4. УСЛУГИ САЙТА
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      4.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Услуги, оказываемые на Сайте, являются зрелищно-развлекательными (графика/анимация, представленные на Сайте) и аттракционными (программа - симулятор). Услуги Сайта служат для удовлетворения личных эмоционально-психологических потребностей Потребителей и строятся по принципу - симулятора. То есть, с помощью представленных на сайте сервисов Потребитель может испытать эмоциональное удовлетворение от своего участия в симуляторе определенных игровых ситуация без принятия на себя бремени возможных негативных последствий того процесса (процесса, который в Услугах на Сайте представлен только в виде симулятора). Услуги сайта – являются имитатором (симулятором), позволяющим получить психо-эмоциональное удовлетворение без каких бы то ни было рисков для Пользователя, в связи с чем, Услуги Сайта относятся к аттракционным. Не допускается сговор между Пользователями в целях использования Услуг Сайта как механизма для организации основанных на риске игр. В случае обнаружения/выявления такого сговора, Администратор принимает меры по блокировки для виновных Пользователей возможности пользоваться Услугами Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      4.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Неиспользованные виртуальные игровые единицы – <span data-v-1aec7022="" class="b-rub">Р</span> могут быть возвращены пользователю в соответствии со стоимостью их приобретения. Возврат осуществляется на платежные реквизиты, которые пользователь указывает в заявке на возврат неиспользованных <span data-v-1aec7022="" class="b-rub">Р</span>.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    5. ПОРЯДОК ПОЛЬЗОВАНИЯ УСЛУГАМИ САЙТА
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      При оказании Услуг Сайта используются виртуальные игровые единицы – <span data-v-1aec7022="" class="b-rub">Р</span>. Виртуальные игровые единицы – являются визуальными изображениями, сгенерированными программным обеспечением Сайта (<span data-v-1aec7022="" class="b-rub">Р</span>). Все права на указанные визуальные изображения (<span data-v-1aec7022="" class="b-rub">Р</span>) принадлежат владельцам соответствующего программного обеспечения и не передаются/не переуступаются Пользователям Сайта ни в право собственности, ни в иное вещное владение и\или обязательственное право. Виртуальные игровые единицы – необходимы для учета прав Пользователей на объем Услуги, которую Пользователь имеет право потребить на Сайте.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Услуги Сайта оказываются путем приобретения и расходования (в предложенных на Сайте аттракционах) виртуальных игровых единиц Услуги Сайта могут быть оказаны как на возмездной (денежной) так и на безденежной основе в зависимости от способа получения Пользователем виртуальных игровых единиц.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.2.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователь может оплатить Услуги Сайта путем внесения денежных средств за покупку виртуальных игровых единиц – <span data-v-1aec7022="" class="b-rub">Р</span>. Способ оплаты указан в параграфе 6 настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Запрещается получать виртуальные игровые единицы с помощью умышленного или неосторожного использования вредоносных/вирусных программ и/или пользуясь недоработками/сбоями в работе Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text"><span data-v-1aec7022="" class="b-rub">Р</span>, имеющиеся на балансе Пользователя, могут быть потрачены последним для участия (совершения Ставки) в разных видах игр, представленных на Сайте в качестве развлекательно-аттракционной Услуги Сайта, по правилам, указанным в разделе Помощь. на Сайте.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.5
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Правила различных аттракционных игр, представленных на Сайте в качестве Услуг Сайта, могут существенно отличаться друг от друга. Правила игр размещены в разделе Помощь и/или в соответствующем разделе Сайта, участвуя в играх, Пользователь соглашается с правилами, указанными на Сайте.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.6
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Для участия в той или иной игре на Сайте Пользователь совершает Ставку, в результате которой с баланса Пользователя списываются <span data-v-1aec7022="" class="b-rub">Р</span> в размере, обусловленном правилами Сайта и пожеланием Пользователя по размеру Ставки.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.7
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В результате участия Пользователя в играх на Сайте баланс виртуальных игровых единиц Пользователя может уменьшаться (при совершении Ставки) и увеличиваться (при достижении обусловленного правилами Сайта результата игры на Сайте).
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.8
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Возможность Пользователя принимать участие в Раундах игры на Сайте продолжается до момента обнуления баланса виртуальных игровых единиц Пользователя на Сайте. При отсутствии у Пользователя оплаченных (и/или иным образом приобретенных в соответствии с п. 5.2. настоящего Соглашения) виртуальных игровых единиц (<span data-v-1aec7022="" class="b-rub">Р</span>) такой Пользователь не может принять участие ни в каких играх, представленных на Сайте.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.9
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор может отменять проведение тех или иных Раундов без предварительного уведомления Пользователей. В указанном случае Администратор восстанавливает на балансе Пользователя на Сайте виртуальные игровые единицы, потраченные Пользователем при совершении Ставки на отмененный Раунд.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.10
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователям, участвующим в Раундах, запрещено предпринимать попытки сговора друг с другом с целью влияния на результат аттракциона (игры) в интересах одного или нескольких из таких Пользователей путем манипулирования ходом игры путем сговора о количестве и размере совершаемых Ставок. Выявление Администратором таких фактов, будет служить основанием к запрету доступа Пользователя к Услугам Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      5.11
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователям ЗАПРЕЩЕНО регистрировать более 1 учетной записи (аккаунтов), без предварительного согласования с администрацией. В случае нарушения – все учетные записи Пользователя будут заблокированы, а баланс игрового счета аннулирован.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    6. ОПЛАТА
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Цены за <span data-v-1aec7022="" class="b-rub">Р</span> на Сайте устанавливаются Администратором и могут быть изменены по решению Администратора. Цены указываются на соответствующей странице Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователь вправе оплатить Услуги Сайта одним из способов оплаты, предусмотренных на Сайте. Оплата производится Пользователем посредством агрегатора электронной системы платежей (электронной платежной системы), позволяющей в реальном времени через сеть Интернет оплачивать товары и услуги, в том числе Услуги Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Обязательства по оплате считаются исполненными Пользователем, в случае положительного результата авторизации платежа в системе электронных платежей, применяемой для оплаты Услуг Сайта. Доказательством совершения оплаты служит информация системы электронных платежей о совершенном платеже.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      При оплате Услуг Сайта по средством системы электронных платежей, применяемой для оплаты Услуг Сайта, платежной системой может взиматься комиссия с Пользователя по правилам платежной системы (системы электронных платежей). Администратор не несет ответственности за взимание таких комиссий платежными системами.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.5
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор не контролирует аппаратно-программный комплекс системы платежей и не несет ответственности за ошибки в таком аппаратно-техническом комплексе. Если в результате таких ошибок произошло списание денежных средств Пользователя, но платеж не был авторизован системой электронных платежей, обязанности по возврату денежных средств Пользователю лежат на провайдере/агрегаторе электронной системы платежей (платежной системы).
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.6
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В случае вопросов или претензий в связи с обслуживанием клиентов обращайтесь к нам по электронной почте boss@kapitan-x.com. Вопросы касательно платежей, совершенных через систему оплаты Поставщика услуг, следует направлять по адресу указанному на сайте Поставщика услуг.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      6.7
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Все оплаченные Услуги Сайта являются добровольными пожертвованиями со стороны Пользователя.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    7. ИНТЕЛЛЕКТУАЛЬНАЯ СОБСТВЕННОСТЬ И ОГРАНИЧЕНИЯ ПРИ ИСПОЛЬЗОВАНИИ САЙТА
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Сайт содержит результаты интеллектуальной деятельности, принадлежащие Администратору, его аффилированным лицам и другим связанным сторонам, спонсорам, партнерам, представителям, всем прочим лицам, действующим от имени Администратора, и другим третьим лицам.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Используя Сайт, Пользователь признает и соглашается с тем, что все содержимое Сайта и структура содержимого Сайта защищены авторским правом, правом на товарный знак и другими правами на результаты интеллектуальной деятельности, и что указанные права являются действительными и охраняются во всех формах, на всех носителях и в отношении всех технологий, как существующих в настоящее время, так и разработанных или созданных впоследствии. Никакие права на любое содержимое Сайта, не переходят к Пользователю в результате использования Сайта и заключения настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Во избежание сомнений, как в целях защиты интеллектуальных прав, так и в любых иных целях, связанных с использованием Сайта, Пользователю запрещается:
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      копировать и/или распространять какие-либо объекты интеллектуальных прав, размещенных на Сайте, кроме случаев, когда такая функция прямо предусмотрена (разрешена) на Сайте;
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      использовать информацию, полученную на Сайте для осуществления коммерческой деятельности, извлечения прибыли, либо для использования противоречащим закону способом;
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      копировать, либо иным способом использовать программную часть Сайта, а также его дизайн;
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      размещать на Сайте персональные данные третьих лиц без их согласия, в том числе домашние адреса, телефоны, паспортные данные, адреса электронной почты;
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.5
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      изменять каким бы то ни было способом программную часть Сайта, совершать действия, направленные на изменение функционирования и работоспособности Сайта;
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.6
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      использовать оскорбительные, вводящие в заблуждение других Пользователей Сайта, нарушающие права и свободы третьих лиц и групп лиц, слова, в том числе: в качестве имени (ника, псевдонима);
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      7.3.7
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      использовать для получения Услуг Сайта программные, технические или аппаратные средства, не предусмотренные Сайтом.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    8. ОТВЕТСТВЕННОСТЬ
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В случае нарушения Пользователем условий настоящего Соглашения, любых иных нормативных документов и правил, размещенных Администратором на Сайте, Администратор вправе в одностороннем внесудебном порядке заблокировать или удалить с Сайта аккаунт Пользователя, запретить либо ограничить доступ Пользователя к определенным или всем функциям Сайта. При этом такая блокировка или ограничения могут быть произведены Администратором без предварительного уведомления Пользователя и начинают действовать с момента принятия такого решения Администратором и совершения последним соответствующих технических действий. В случае блокировки или ограничения Администратором доступа Пользователя к аккаунту Пользователя на Сайте и/или Услугам Сайта по причине нарушения Пользователем условий настоящего Соглашения, любых иных нормативных документов и правил, размещенных Администратором на Сайте (что квалифицируется как – виновные (как умышленные так и неосторожные) действия со стороны Пользователя Сайта), имеющиеся на балансе Пользователя на Сайте <span data-v-1aec7022="" class="b-rub">Р</span> (виртуальные игровые единицы) аннулируются и не подлежат компенсации Администратором Пользователю ни в каком виде.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор не отвечает за работоспособность Сайта и не гарантирует его бесперебойной работы. Администратор также не гарантирует сохранности информации, размещенной на Сайте и возможности бесперебойного доступа к Услугам Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Если из-за сбоя в работе аппаратно-программной части Сайта тот или иной Раунд игры (развлекательной Услуги Сайта) был завершен некорректно (не по правилам, указанным на Сайте), любой из Пользователей, участвовавший в соответствующем Раунде, в течение суток вправе заявить возражения на результат такого Раунда с указанием причин, воспользовавшись специальной формой обратной связи на Сайте. После рассмотрения такого возражения результат такого Раунда может быть аннулирован, а использованные Ставки - возвращены участвовавшим Пользователям. В противном случае Раунд признается состоявшимся.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователь использует Сайт в том виде, в каком он представлен в сети Интернет по сетевому адресу: <?echo  $_SERVER['HTTP_HOST'];?>. Администратор не гарантирует Пользователю достижения каких-либо результатов вследствие использования Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.5
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор не несет ответственности перед Пользователем и не обязан предоставлять Услуги Сайта в случае, если Пользователь приобрел виртуальные игровые единицы способами отличными от указанных в п. 5.2. настоящего Соглашения.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.6
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор не несет ответственности за несовпадение субъективного впечатления Пользователя от Сайта и Услуг Сайта с ожиданиями Пользователя. Администратор не несет ответственности за то, какое действие и впечатления оказывают на Пользователя дизайн Сайта, шрифты и стиль размещения контента на Сайте.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      8.7
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор не гарантирует и не несет ответственности в случае если использование Услуг Сайта нормативно запрещено и/или ограничено в той юрисдикции, в которой находится Пользователь в момент захода на Сайт и/или использования Услуг Сайта.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    9. ОСОБЫЕ УСЛОВИЯ
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      9.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Сайт может содержать ссылки на другие сайты в сети Интернет (сайты третьих лиц). Указанные третьи лица и их контент не проверяются Администратором на соответствие тем или иным требованиям (достоверности, полноты, законности и т.п.). Администратор не несет ответственности за любую информацию, материалы, размещенные на сайтах третьих лиц, к которым Пользователь получает доступ в связи с использованием Сайта, в том числе: за любые мнения или утверждения, выраженные на сайтах третьих лиц, рекламу и т.п., а также за доступность таких сайтов или контента и последствия их использования Пользователем.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      9.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор не гарантирует, что Сайт соответствует требованиям Пользователя, что доступ к Сайту будет предоставляться непрерывно, быстро, надежно и без ошибок. Программно-аппаратные ошибки, как на стороне Администратора, так и на стороне Пользователя, приведшие к невозможности получения Пользователем доступа к Сайту и/или личному аккаунту Пользователя на Сайте, являются обстоятельствами непреодолимой силы и основанием освобождения от ответственности за неисполнение обязательств Администратором по Соглашению.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      9.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор вправе уступать права и переводить долги по всем обязательствам, возникшим из Соглашения. Настоящим Пользователь дает свое согласие на уступку прав и перевод долга любым третьим лицам. О состоявшейся уступке прав и/или переводе долга Администратор информирует Пользователя, размещая соответствующую информацию на Сайте и такое уведомление Стороны признают достаточным.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      9.4
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Администратор вправе отказать любому Пользователю в обслуживании на Сайте без объяснения причин.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      9.5
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В некоторых случаях использования Сайта (в том числе, но, не ограничиваясь: в случае возникновения спора между Сторонами, в случае предоставления Пользователю каких-либо эксклюзивных опций на Сайте и в иных случаях, перечень не закрытый) Администратором может быть предложено Пользователю сообщить Администратору персональные данные Пользователя. В этом случае, предоставляя свои персональные данные, Пользователь тем самым соглашается (без совершения на то каких бы то ни было дополнительных формальных процедур кроме акцепта настоящего Соглашения) на то, что Администратор вправе обрабатывать персональные данные, предоставленные Пользователем, т.е. совершать любое действие (операция) или совокупность действий (операций), совершаемых с использованием средств автоматизации или без использования таких средств с персональными данными, включая сбор, запись, систематизацию, накопление, хранение, уточнение (обновление, изменение), извлечение, использование, передачу (распространение, предоставление, доступ), обезличивание, блокирование, удаление, уничтожение персональных данных, предоставленных Пользователем.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    10. ПОРЯДОК РАЗРЕШЕНИЯ СПОРОВ
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      10.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Все споры, разногласия и претензии, которые могут возникнуть в связи с исполнением, расторжением или признанием недействительным Соглашения, Стороны будут стремиться решить путем переговоров. Сторона, у которой возникли претензии и/или разногласия, направляет другой Стороне сообщение с указанием возникших претензий и/или разногласий.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      10.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В случае если ответ на сообщение не будет получен направившей сообщение Стороной в течение 30 (тридцати) рабочих дней с даты направления соответствующего сообщения, либо если Стороны не придут к соглашению по возникшим претензиям и/или разногласиям в течение того же срока, спор подлежит разрешению в судебном порядке по месту нахождения Администратора.
                    </div>
                  </div>
                </div>
                <div data-v-1aec7022="" class="terms__group">
                  <div data-v-1aec7022="" class="subtitle terms__subtitle">
                    11. ЗАКЛЮЧИТЕЛЬНЫЕ ПОЛОЖЕНИЯ
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      11.1
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      В случае возникновения формального спора и передачи дела на рассмотрение в соответствующий суд, если судом какое-либо положения настоящего Соглашения будет признано недействительным и/или не подлежащим принудительному исполнению, это не влечет недействительности иных положений Соглашения, не затронутых такой трактовкой суда.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      11.2
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Бездействие со стороны Администратора в случае нарушения кем-либо из Пользователей положений Соглашения не лишает Администратора права предпринять позднее соответствующие действия в защиту своих интересов и защиту интеллектуальных прав на охраняемые материалы и интересы Сайта.
                    </div>
                  </div>
                  <div data-v-1aec7022="" class="terms__item">
                    <div data-v-1aec7022="" class="terms__number">
                      11.3
                    </div>
                    <div data-v-1aec7022="" class="terms__text">
                      Пользователь подтверждает, что ознакомился со всеми положениями настоящего Соглашения, понимает и принимает их в полном объеме и без изъятий/оговорок.
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
        <div data-v-31cda96b="">
          <footer class="footer" data-v-28d2291f="">
            <div class="footer__wrap" data-v-28d2291f="">
              <div class="footer__row" data-v-28d2291f="">
                <div class="footer__col" data-v-28d2291f="">
                  <div class="footer__sitename" data-v-28d2291f="">
                    © <? echo $site_name;?> — 2020
                  </div>
                  <div class="footer__adverts" data-v-28d2291f="">
                    Почта: <a href="mailto:support@<? echo $site_name;?>.win" data-v-28d2291f="">support@<? echo $site_name;?>.win</a></div>
                </div>
                <div class="footer__col" data-v-28d2291f=""><a href="/terms" data-v-28d2291f="" class="nuxt-link-exact-active nuxt-link-active">
          Пользовательское<br data-v-28d2291f="">соглашение
        </a> <a href="/privacy" data-v-28d2291f="" class="">
          Политика<br data-v-28d2291f="">конфиденциальности
        </a>
                  <a href="<? echo $group_vk;?>" target="_blank" class="footer__button vk" data-v-28d2291f=""></a>
                  <a href="https://t.me/joinchat/AAAAAFhiRyzSc-wTgM1eXQ" target="_blank" class="footer__button telegram" data-v-28d2291f=""></a>
                </div>
              </div>
            </div>
          </footer>
        </div>
        <div class="vue-notification-group" style="width:300px;top:0px;left:calc(50% - 150px);" data-v-31cda96b=""><span></span></div>
        <!---->
        <!---->
        <!---->
        <!---->
        <!---->
        <!---->
        <div class="chat_mobile__wrapper" data-v-31cda96b="">
          <!---->
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
  <script async="" src="https://mc.yandex.ru/metrika/tag.js"></script>
  <script>
    window.__NUXT__ = (function(a, b, c, d, e, f, g, h) {
      return {
        layout: "default",
        data: [{}],
        error: c,
        state: {
          auth: {
            isLoggedIn: e,
            accessToken: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJXaW5iZWUiLCJzdWIiOiJhNTMwYzFkNi1lNWE4LTQ2NWMtYjE0Ny0zYjM5OTE3MjJkMDYiLCJpYXQiOjE1ODA1MDQ5MDgsImV4cCI6MTYxMjA0MDkwN30.DDNySUTbGovNmBV6-CxFjpQpuoiuduX1RH4Mr0zAj3I"
          },
          chat: {
            online: a,
            messages: []
          },
          live: {
            queue: [],
            games: []
          },
          partner: {
            percent: f,
            link: "",
            totalFriends: a,
            totalProfit: a,
            referrals: []
          },
          user: {
            id: "a530c1d6-e5a8-465c-b147-3b3991722d06",
            username: "dfdfgfgf",
            balance: {
              btc: a,
              usd: a,
              rub: .0061,
              uah: a,
              kzt: a
            }
          },
          games: {
            dice: {
              gameCounter: a,
              gameNumber: a,
              reverse: b,
              rollOver: g,
              bet: d,
              chance: g,
              x: 2,
              win: .02
            },
            mines: {
              bombItems: [h, f, 10, 24],
              bombs: h,
              odds: [],
              bet: d,
              winOdds: c,
              winAmount: c,
              gameId: c,
              steps: [],
              field: [a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a, a],
              isLoadingNewGame: b,
              isLoadingEndGame: b,
              isGameOver: b,
              isShowWinPopup: b,
              errorsNewGame: []
            },
            wheel: {
              bet: d,
              mode: 1,
              segment: a,
              x: a,
              win: a,
              isAnimate: b,
              isEnd: b
            }
          }
        },
        serverRendered: e
      }
    }(0, false, null, .01, true, 5, 49.5, 3));
  </script>
  <script src="/_nuxt/6ba65d7d2a278b53c9ad.js" defer=""></script>
  <script src="/_nuxt/d7687b6839a98c59cdd8.js" defer=""></script>
  <script src="/_nuxt/ea4d0e1418afcfa94ce5.js" defer=""></script>
  <script src="/_nuxt/5bac75f34425993c48d3.js" defer=""></script>
  <script src="/_nuxt/d134dc5d8c6407c75152.js" defer=""></script>
  <!-- Yandex.Metrika counter -->
  <script type="text/javascript">
    ! function(e, t, a, n, c, m, r) {
      e.ym = e.ym || function() {
        (e.ym.a = e.ym.a || []).push(arguments)
      }, e.ym.l = 1 * new Date, m = t.createElement(a), r = t.getElementsByTagName(a)[0], m.async = 1, m.src = "https://mc.yandex.ru/metrika/tag.js", r.parentNode.insertBefore(m, r)
    }(window, document, "script"), ym(55970746, "init", {
      clickmap: !0,
      trackLinks: !0,
      accurateTrackBounce: !0,
      webvisor: !0
    })
  </script>
  <noscript>
    <div><img src="https://mc.yandex.ru/watch/55970746" style="position:absolute;left:-9999px" alt=""></div>
  </noscript>
  <!-- /Yandex.Metrika counter -->
  <!-- Global Site Tag Google Analytics -->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-151026933-1"></script>
  <script>
    function gtag() {
      dataLayer.push(arguments)
    }
    window.dataLayer = window.dataLayer || [], gtag("js", new Date), gtag("config", "UA-151026933-1")
  </script>
  <!-- /Global Site Tag Google Analytics -->

  <iframe name="ym-native-frame" title="ym-native-frame" frameborder="0" aria-hidden="true" style="opacity: 0 !important; width: 0px !important; height: 0px !important; position: absolute !important; left: 100% !important; bottom: 100% !important; border: 0px !important;"></iframe>
  <ym-measure class="ym-viewport" style="display: block; top: 0px; right: 0px; bottom: 0px; left: 0px; position: fixed; transform: translate(0px, -100%); transform-origin: 0px 0px;"></ym-measure>
  <ym-measure class="ym-zoom" style="bottom: 100%; position: fixed; width: 100vw;"></ym-measure>
</body>

</html>