/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$( document ).ready(function() {
    $("label[data-v-65fbf9de").click(function(){

            var mode = $(this).attr("data-mode");
            $("label[data-mode]").removeClass('active');
            $("label[data-mode="+mode+"]").addClass('active');

            if(mode == 'easy'){
            $(".legend-wheel-winner").hide()
            $(".legend-wheel-img").attr("src","images/wheels/1.svg");
            $(".legend-wheel-coefficient-box").html('<div data-v-6fa0bf79="" class="legend-wheel-coefficient-list"><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#3a2a56" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X0.0</span></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#9b5aff" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X1.2</span></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#ffed2a" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X1.5</span></div></div>');
            $(".legend-wheel-img").css({"transform":"rotate(18deg)","transition":"0s"});      
        }
            if(mode == 'medium'){
                $(".legend-wheel-winner").hide()
                $(".legend-wheel-img").attr("src","images/wheels/2.svg");
                $(".legend-wheel-coefficient-box").html('<div class="legend-wheel-coefficient-list" data-v-6fa0bf79=""><div class="legend-wheel-coefficient-item" data-v-6fa0bf79=""><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16" data-v-6fa0bf79=""><circle fill="#3a2a56" r="7" cx="7" cy="7" data-v-6fa0bf79=""></circle></svg> <span data-v-6fa0bf79="">X0.0</span></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#9b5aff" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X1.5</span></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#ffed2a" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X2.0</span></div></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-list"><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#00e402" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X3.0</span></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#ff4a60" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X5.0</span></div></div>');
                $(".legend-wheel-img").css({"transform":"rotate(147deg)","transition":"0s"});
            }
                if(mode == 'hard'){
                    $(".legend-wheel-winner").hide()
                    $(".legend-wheel-img").attr("src","images/wheels/3.svg");
                    $(".legend-wheel-coefficient-box").html('<div class="legend-wheel-coefficient-list" data-v-6fa0bf79=""><div class="legend-wheel-coefficient-item" data-v-6fa0bf79=""><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16" data-v-6fa0bf79=""><circle fill="#3a2a56" r="7" cx="7" cy="7" data-v-6fa0bf79=""></circle></svg> <span data-v-6fa0bf79="">X0.0</span></div><div data-v-6fa0bf79="" class="legend-wheel-coefficient-item"><svg data-v-6fa0bf79="" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="-1 -1 16 16"><circle data-v-6fa0bf79="" fill="#ff4a60" r="7" cx="7" cy="7"></circle></svg> <span data-v-6fa0bf79="">X49.5</span></div></div>');
                    $(".legend-wheel-img").css({"transform":"rotate(97deg)","transition":"0s"});
                }

    })
})

function playWheel(){
    var mode = $('.active').attr("data-mode");
    $('.legend-wheel-img').css({"transform":"rotate(0deg)","transition":"0s"})
    $('.error').css('display','none');
    if(mode == 'easy'){
        var key_mode = 18;
    }
    if(mode == 'medium'){
        var key_mode = 147;
    }
    if(mode == 'hard'){
        var key_mode = 97;
    }
    $.ajax({
        url: 'inc/engine.php',
        dataType: 'html',
        beforeSend: function(){
            $(".legend-wheel-winner").hide()
        },
        type: 'POST',
        data:{
            type: 'play_wheel',
            mode: mode,
            bet: $("#bet").val()
        },
        success: function(data){
            obj = $.parseJSON(data);
            if(obj.notification == 'error'){
                $('.error').css('display','block').text(obj.mess);
            }
            if(obj.notification == 'play'){
                var key = obj.key * 7.2 + key_mode + 360;
                $('.legend-wheel-img').css({"transform":"rotate("+key+"deg)","transition":"transform 5s cubic-bezier(.46,.07,.04,.98),-webkit-transform 4.5s cubic-bezier(.46,.07,.04,.98)"})
                $(".legend-wheel-winner-coefficient").text("x"+obj.win)
                $('.legend-wheel-prize-integer').text(obj.win_sum)

                setTimeout(function(){
                    $(".legend-wheel-winner").show()
                },5000);

                if(obj.win == 0){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(255, 255, 255) 0px 0px 80px 0px, rgb(255, 255, 255) 0px 0px 20px 0px, rgb(255, 255, 255) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(255, 255, 255)')
                    $(".legend-wheel-winner-coefficient").text("x"+obj.win+".00")
                }
                if(obj.win == 1.2){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(155, 90, 255) 0px 0px 80px 0px, rgb(155, 90, 255) 0px 0px 20px 0px, rgb(155, 90, 255) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(155, 90, 255)')
                    $(".legend-wheel-winner-coefficient").text("x1.20")
                }
                if(obj.win == 1.5){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(255, 237, 42) 0px 0px 80px 0px, rgb(255, 237, 42) 0px 0px 20px 0px, rgb(255, 237, 42) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(255, 237, 42)')
                    $(".legend-wheel-winner-coefficient").text("x1.50")
                    if(mode == 'medium'){
                        $(".legend-wheel-winner").css({'box-shadow':'rgb(155, 90, 255) 0px 0px 80px 0px, rgb(155, 90, 255) 0px 0px 20px 0px, rgb(155, 90, 255) 0px 0px 5px 2px'});
                        $('.legend-wheel-winner-coefficient').css('background','rgb(155, 90, 255)')
                        $(".legend-wheel-winner-coefficient").text("x1.50")
                    }
                }
                if(obj.win == 2){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(255, 237, 42) 0px 0px 80px 0px, rgb(255, 237, 42) 0px 0px 20px 0px, rgb(255, 237, 42) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(255, 237, 42)')
                    $(".legend-wheel-winner-coefficient").text("x"+obj.win+".00")
                }
                if(obj.win == 3){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(0, 220, 2) 0px 0px 80px 0px, rgb(0, 221, 2) 0px 0px 20px 0px, rgb(0, 219, 2) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(0, 221, 2)')
                    $(".legend-wheel-winner-coefficient").text("x"+obj.win+".00")
                }
                if(obj.win == 5){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(236, 68, 89) 0px 0px 80px 0px, rgb(227, 66, 85) 0px 0px 20px 0px, rgb(233, 68, 88) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(238, 69, 90)')
                    $(".legend-wheel-winner-coefficient").text("x"+obj.win+".00")
                }
                if(obj.win == 50){
                    $(".legend-wheel-winner").css({'box-shadow':'rgb(236, 68, 89) 0px 0px 80px 0px, rgb(227, 66, 85) 0px 0px 20px 0px, rgb(233, 68, 88) 0px 0px 5px 2px'});
                    $('.legend-wheel-winner-coefficient').css('background','rgb(238, 69, 90)')
                    $(".legend-wheel-winner-coefficient").text("x"+obj.win+".00")
                }
                var money = obj.money;
                setTimeout(function(){
                    $('.balance span').text(money)
                },5000)
            }
        }
    });
}
function sendMess(){
    var mess = $(".chat-options-input-text").val()
    if(mess.length > 2){
    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'sendMess',
                mess: mess,
            },
            success: function(data){
                obj = $.parseJSON(data);
            $(".chat-options-input-text").val('')
            if(obj.success == 'false'){
                toastr['error'](obj.mess)
            }
            }
    })
    }else{
        toastr['error']('Введите больше двух символов')
    }
    }
    function intervalChat(){
        $.ajax({
            url: "inc/engine.php",
                type: "POST",
                dataType: "html",
                data: {
                    type: 'obnovaChat',
                },
                success: function(data){
                    obj = $.parseJSON(data);
        
                  $('.chat-messages-container').html(obj.chat).scrollTop('999999');
                }
    })
    }
    setInterval(intervalChat,1500);

    function amountInp(amount){
        var bet = $("#bet").val();
        switch (amount) {
            case 'x2':
              $('#bet').val(bet * 2)
              break;
            case '1/2':
                $('#bet').val(bet / 2)
              break;
            case 'min':
                $('#bet').val(1)
              break;
              case 'max':
                $('#bet').val(1000)
                break;
          }
    }
    