/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$(function(){
    $('.cell').click(function(){
        var cell = $(this).attr('data-faucet');
        $.ajax({
            url: "inc/engine.php",
                type: "POST",
                dataType: "html",
                data: {
                    type: 'faucet',
                    cell: cell
                },
                success: function(data){
                    obj = $.parseJSON(data);

                  if(obj.success == 'good'){
                      obj.taprice = $.parseJSON(obj.taprice);
                      $('.ribbon__text').text('БОНУС НАЧИСЛЕН');
                      $('div[data-v-8ad8d56a]').html(obj.lool)
                      $(".balance span").text(obj.money);
                      $('.cell[data-faucet='+obj.cell+']').removeClass('is__opacity');

                  }
                    
                    
   
                }
    })
    });
})
    
function freeMoney(){
    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'free',
            },
            success: function(data){
                obj = $.parseJSON(data);
                
                if(obj.success == 'error'){
                    alert(obj.mess);
                }
                if(obj.success == 'start'){
                    $('.faucet__form').html('');
                    $('.ribbon__text').text('ВЫБИРАЙ ЛЮБУЮ');
                    $('.faucet__form').html('<div data-v-8ad8d56a="" data-v-37389b4b="" class="field"><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="1"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="2"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="3"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="4"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="5"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="6"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="7"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="8"><div data-v-7619dbb8="" class="round"></div> <!----></div><div data-v-7619dbb8="" data-v-8ad8d56a="" class="cell is__opacity" data-faucet="9"><div data-v-7619dbb8="" class="round"></div> <!----></div></div>')
                }
             
            }
})
}