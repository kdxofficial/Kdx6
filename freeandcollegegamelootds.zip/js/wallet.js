/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$( document ).ready(function(){
    $('.box').click(function(){
        var box = $(this).attr('data-box');
        $('.box').removeClass('active')
        $('.box[data-box='+box+']').addClass('active')
        if(box == 'deposit'){
            $('.deposit-tab').css('display','block')
            $('.withdraw-tab').css('display','none')
        }else{
            $('.deposit-tab').css('display','none')
            $('.withdraw-tab').css('display','block')
        }
    })
    $('.payment-system').click(function(){
        var paymentSystem = $(this).attr('data-payment');
        $('.payment-system').removeClass('payment-system_active')
        $('.payment-system[data-payment='+paymentSystem+']').addClass('payment-system_active')
        if(paymentSystem == 'qiwi'){
            $('#payment').text('Киви');
            $('#paymentComissia').text('2')
            $('#withdraw-number_wallet').text('Номер телефона')
            $('#withdraw-wallet').attr('placeholder','+79123456789')
        }
        if(paymentSystem == 'yandex'){
            $('#payment').text('Яндекс');
            $('#paymentComissia').text('2.5')
            $('#withdraw-number_wallet').text('Номер кошелька')
            $('#withdraw-wallet').attr('placeholder','4100XXXXXXXXXXXX')
        }
        if(paymentSystem == 'karta'){
            $('#payment').text('Карта');
            $('#paymentComissia').text('50 + 2.5')
            $('#withdraw-number_wallet').text('Номер карты')
            $('#withdraw-wallet').attr('placeholder','4276XXXXXXXXXXX')
        }
        if(paymentSystem == 'mts'){
            $('#payment').text('МТС');
            $('#paymentComissia').text('3')
            $('#withdraw-number_wallet').text('Номер телефона')
            $('#withdraw-wallet').attr('placeholder','+79123456789')
        }
        if(paymentSystem == 'beeline'){
            $('#payment').text('Билайн');
            $('#paymentComissia').text('3')
            $('#withdraw-number_wallet').text('Номер телефона')
            $('#withdraw-wallet').attr('placeholder','+79123456789')
        }
        if(paymentSystem == 'megafon'){
            $('#payment').text('Мегафон');
            $('#paymentComissia').text('3')
            $('#withdraw-number_wallet').text('Номер телефона')
            $('#withdraw-wallet').attr('placeholder','+79123456789')
        }
        if(paymentSystem == 'tele2'){
            $('#payment').text('Теле2');
            $('#paymentComissia').text('3')
            $('#withdraw-number_wallet').text('Номер телефона')
            $('#withdraw-wallet').attr('placeholder','+79123456789')
        }
    });
})
function withdraw(){
    var number_wallet = $('#withdraw-wallet').val()
    var amount_wallet = $('#withdraw-amount').val()
    var payment_wallet = $('.payment-system_active').attr('data-payment');

    if(payment_wallet != null){
    if(number_wallet.length >= 8){
    $.ajax({
        url: "inc/engine.php",
        type: "POST",
        dataType: "html",
        data: {
            type: 'withdraw',
            number: number_wallet,
            amount: amount_wallet,
            payment: payment_wallet,
        },
        success: function(data){
            obj = $.parseJSON(data);
   
            if(obj.notification == 'false'){
                toastr['error'](obj.mess);
            }
            if(obj.notification == 'true'){
                var payment_wallet = $('.payment-system_active').attr('data-payment');
                $('.jfjdfdfd').prepend('<tr data-v-6a6b5a56=""><td data-v-6a6b5a56="">Только что</td><td data-v-6a6b5a56=""><img data-v-6a6b5a56="" src="/images/ps/'+payment_wallet+'_rub.png"> <span data-v-6a6b5a56="">'+payment_wallet+'</span></td><td data-v-6a6b5a56="">'+amount_wallet+'₽</td><td data-v-6a6b5a56=""><span data-v-6a6b5a56="">Ожидание</span></td></tr>')
                toastr['success'](obj.mess);
                $('.balance span').text(obj.money)
            }


        }
    });
}else{
    toastr['error']('Номер/Кошелек от 8 цифр');
}
}else{
    toastr['error']('Выберите кошелек');
}
}
function amount_wallet(amount){
    $('#deposit-amount').val(amount);
}
function deposit(){
    var deposit_sum = $('#deposit-amount').val();

    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'deposit',
                deposit_sum: deposit_sum,
            },
            success: function(data){
                obj = $.parseJSON(data);
                if(obj.notification == 'false'){
                    toastr['error'](obj.mess);
                }
                if(obj.notification == 'true'){
                    window.location.replace(obj.link);
                }
            }
})
}