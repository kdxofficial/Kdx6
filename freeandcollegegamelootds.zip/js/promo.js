/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
function promo(){
    $.ajax({
        url: "inc/engine.php",
            type: "POST",
            dataType: "html",
            data: {
                type: 'activ_promo',
                promo: $('#code').val(),
            },
            success: function(data){
                obj = $.parseJSON(data);
              if(obj.notification == 'true'){
               toastr["success"](obj.mess)
               $('.balance span').text(obj.money)
              }else{
               toastr["error"](obj.mess)
              }
            }
})
}