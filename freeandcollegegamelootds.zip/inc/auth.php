<?php
include_once("./bd.php");
include_once("./config.php");
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$client_id = "$client_id"; // ID приложения
$client_secret = "$client_secret"; // Защищённый ключ
$redirect_uri = "$domen/inc/auth.php"; // Адрес сайта
$url = 'http://oauth.vk.com/authorize';

if (isset($_GET['code'])) {
    $result = true;
    $params = [
        'client_id' => $client_id,
        'client_secret' => $client_secret,
        'code' => $_GET['code'],
        'redirect_uri' => $redirect_uri
    ];

    $token = json_decode(file_get_contents('https://oauth.vk.com/access_token' . '?' . urldecode(http_build_query($params))), true);

    if (isset($token['access_token'])) {
        $params = [
            'uids' => $token['user_id'],
            'fields' => 'uid,first_name,last_name,screen_name,sex,bdate,photo_big',
            'access_token' => $token['access_token'],
            'v' => '5.101'];

        $userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get' . '?' . urldecode(http_build_query($params))), true);
        if (isset($userInfo['response'][0]['id'])) {
            $userInfo = $userInfo['response'][0];
            $result = true;
        }
    }

function generateSid($length = 25){
$chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
$numChars = strlen($chars);
$string = '';
for ($i = 0; $i < $length; $i++) {
$string .= substr($chars, rand(1, $numChars) - 1, 1);
}
return $string;
}
$sid = generateSid(25);

    $vk_id = $userInfo['id'];
    $name = $userInfo['first_name'];
    $last_name = $userInfo['last_name'];
    $login = "$name $last_name";
    $photo = $userInfo['photo_big'];

  $query = ("SELECT * FROM `users` WHERE `vk_id` = '$vk_id'");
  $result1 = mysqli_query($link,$query);
	if(mysqli_num_rows($result1) > 0)
	{
$query = ("UPDATE `users` SET `sid` = '$sid' WHERE `vk_id` = '$vk_id'");
mysqli_query($link,$query);
	//юзер существует (обновление хеша, аватарки, имя)
  setcookie('sid', $sid, time()+3600*60, '/');
  header("Location: /");
	}
else{
  //юзера не существует
     $ip = $_SERVER['REMOTE_ADDR']; // получаем айпи юзера
     $today2 = date("d.m.y");
     $today3 = date("H:i:s");
     $data = "$today2 $today3";
 
     if($_COOKIE['ref'] > 1 && $_COOKIE['ref'] <= 20000){
     $invited = $_COOKIE['ref'];
     $query = ("SELECT * FROM `users` WHERE `id` = '$invited'");
     $result2 = mysqli_query($link,$query); 
     $row5 = mysqli_fetch_array($result2);
     if($row5){
     $referalov_ref = $row5['referalov'];
     $query = ("UPDATE `users` SET `referalov` = '$referalov_ref'+ '1' WHERE `id` = '$invited'");
     mysqli_query($link,$query);
     }   
     }


 
     $query = ("INSERT INTO `users` (`sid`,`vk_id`, `login`, `money`, `photo_vk`,`ip`,`data`,`invited`) VALUES ('$sid','$vk_id', '$login', '$bonus', '$photo','$ip','$data','$invited')");
     mysqli_query($link,$query);
     setcookie('sid', $sid, time()+3600*600, '/');

	  header("Location: /");
    }

}
?>
