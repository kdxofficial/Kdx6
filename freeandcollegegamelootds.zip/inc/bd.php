<?
/*
Автор скрипта - OFF-BOT.RU, по всем вопросам пишите мне.
*/
$link = mysqli_connect("localhost", "root", "", "mybase")
    or die("Ошибка " . mysqli_error($link));

?>